// Iniettato in music.apple.com: segue MusicKit e riceve i comandi dall'app.
(() => {
  if (window.__aria) return;
  const send = (type, payload) => window.ariaBridge && window.ariaBridge.send(type, payload);
  let mk = null;

  const artUrl = (item, size) => {
    const art = item.artwork || (item.attributes && item.attributes.artwork);
    if (!art || !art.url) return null;
    return art.url.replace('{w}', size).replace('{h}', size).replace('{f}', 'jpg').replace('{c}', '');
  };

  const track = () => {
    const it = mk.nowPlayingItem;
    if (!it) return null;
    const attrs = it.attributes || {};
    const art = attrs.artwork || it.artwork || {};
    return {
      id: it.id,
      title: it.title || attrs.name || '',
      artist: it.artistName || attrs.artistName || '',
      album: it.albumName || attrs.albumName || '',
      art: artUrl(it, 600),
      color: art.bgColor || null,
      genre: (attrs.genreNames && attrs.genreNames.find((g) => g !== 'Musica' && g !== 'Music')) || (attrs.genreNames || [])[0] || '',
    };
  };

  const playback = () => ({
    playing: !!mk.isPlaying,
    time: mk.currentPlaybackTime || 0,
    duration: mk.currentPlaybackDuration || 0,
    shuffle: !!mk.shuffleMode,
    repeat: mk.repeatMode || 0,          // 0 no, 1 un brano, 2 tutti
    volume: Math.round((mk.volume || 0) * 100) / 100,
  });

  // ---------- Audio ----------
  const audio = { fadeMs: 0, sinkLabel: '', pauseOnUnplug: true };
  let fadeState = null; // dissolvenza del timer di spegnimento in corso
  const styleCache = {}; // ultime variabili CSS scritte su :root
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // Il lettore audio di MusicKit non è nella pagina: lo si intercetta quando parte, per scegliere l'uscita
  const mediaEls = new Set();
  const origPlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function (...args) {
    if (this.tagName === 'AUDIO' || !this.muted) { mediaEls.add(this); applySink(this); }
    if (ap.wanted && this.tagName === 'AUDIO') airplayRoute();
    return origPlay.apply(this, args);
  };

  // AirPlay: l'audio del lettore passa da qui e va all'app a blocchi di 0,1 s (PCM 16 bit stereo). Una volta
  // agganciato, il lettore suona solo attraverso questo grafo: a PC va collegato alle casse, in AirPlay no.
  // Il segnale arriva già abbassato dal volume del lettore: il guadagno lo riporta pieno, perché il volume
  // lo applica il dispositivo
  const AP_WORKLET = `registerProcessor('beats-ap', class extends AudioWorkletProcessor {
    constructor() { super(); this.out = new Int16Array(8820); this.n = 0; }
    process(inputs) {
      const ch = inputs[0], l = ch[0], r = ch[1] || l;
      for (let i = 0; i < 128; i++) {
        const a = l ? l[i] : 0, b = r ? r[i] : 0;
        this.out[this.n++] = Math.max(-1, Math.min(1, a)) * 32767;
        this.out[this.n++] = Math.max(-1, Math.min(1, b)) * 32767;
        if (this.n === this.out.length) { const copy = this.out.slice(0); this.port.postMessage(copy.buffer, [copy.buffer]); this.n = 0; }
      }
      return true;
    }
  });`;
  const ap = { wanted: false, ctx: null, src: null, gain: null, node: null, loading: null, meter: null, analyser: null };
  // Il dispositivo suona circa 1,1 s dopo il lettore (il suo margine più il viaggio dei blocchi): mentre AirPlay
  // è attivo il lettore dichiara il tempo di ciò che si sente, così testo e barra di avanzamento restano a tempo.
  // Una richiesta di salto all'inizio del brano resta all'inizio, altrimenti se ne perderebbe il primo secondo
  const AP_DELAY = 1.1;
  const mediaTime = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'currentTime');
  function apShiftClock(el, on) {
    if (!on) { delete el.currentTime; return; }
    Object.defineProperty(el, 'currentTime', {
      configurable: true,
      get() { return Math.max(0, mediaTime.get.call(this) - AP_DELAY); },
      set(v) { mediaTime.set.call(this, v < AP_DELAY ? v : v + AP_DELAY); },
    });
  }
  // Il segnale arriva già abbassato dal volume del lettore: si riporta su, così AirPlay e le onde non dipendono dal volume
  const apGain = () => {
    if (!ap.ctx || !mk) return;
    const v = mk.volume, k = v > 0.005 ? 1 / v : 0, now = ap.ctx.currentTime;
    if (ap.gain) ap.gain.gain.setTargetAtTime(k, now, 0.01);
    if (ap.meter) ap.meter.gain.setTargetAtTime(k, now, 0.01);
  };
  // Il grafo audio serve ad AirPlay e alle onde del lettore grande. Una volta agganciato, il lettore suona attraverso il
  // grafo finché Beats resta aperta: si aggancia solo a contesto già partito, altrimenti la musica resterebbe muta
  function audioGraph(el) {
    if (!ap.loading) {
      ap.loading = (async () => {
        const ctx = new AudioContext({ sampleRate: 44100, latencyHint: 'playback' });
        await Promise.race([ctx.resume(), sleep(1500)]);
        if (ctx.state !== 'running') { ctx.close().catch(() => {}); throw new Error('contesto audio fermo'); }
        ap.ctx = ctx;
        ap.meter = ctx.createGain();
        ap.analyser = ctx.createAnalyser();
        ap.analyser.fftSize = 1024;
        ap.analyser.smoothingTimeConstant = 0.2;
        ap.analyser.minDecibels = -78;
        ap.analyser.maxDecibels = -18;
        ap.meter.connect(ap.analyser);
        apGain();
        ap.src = ctx.createMediaElementSource(el);
        ap.src.connect(ctx.destination);
        ap.src.connect(ap.meter);
        apApplySink();
      })().catch((e) => { ap.loading = null; throw e; });
    }
    return ap.loading;
  }
  async function airplayRoute() {
    const el = document.getElementById('apple-music-player');
    if (!el) return; // il lettore nasce al primo brano: si riprova quando parte
    if (!ap.src && !ap.wanted) return;
    await audioGraph(el);
    if (ap.wanted && !ap.node) {
      const url = URL.createObjectURL(new Blob([AP_WORKLET], { type: 'text/javascript' }));
      await ap.ctx.audioWorklet.addModule(url);
      URL.revokeObjectURL(url);
      ap.node = new AudioWorkletNode(ap.ctx, 'beats-ap', { numberOfOutputs: 0 });
      ap.node.port.onmessage = (e) => { if (ap.wanted) send('apcm', e.data); };
      ap.gain = ap.ctx.createGain();
      ap.gain.connect(ap.node);
    }
    try { await ap.ctx.resume(); } catch {}
    apShiftClock(el, ap.wanted);
    ap.src.disconnect();
    ap.src.connect(ap.meter);
    if (ap.wanted) { apGain(); ap.src.connect(ap.gain); }
    else {
      ap.src.connect(ap.ctx.destination);
      apApplySink();
    }
  }
  // Una volta agganciato il lettore suona attraverso il grafo: l'uscita scelta va impostata qui, non sul lettore
  async function apApplySink() {
    if (!ap.src || ap.wanted || !ap.ctx.setSinkId) return;
    try { await ap.ctx.setSinkId(await sinkId()); } catch {}
  }
  // '' = uscita predefinita di Windows. L'id del dispositivo scelto si cerca una volta sola
  // (si ricalcola quando cambia la scelta o i dispositivi collegati)
  let sinkCache = null; // { label, id }
  async function sinkId() {
    if (!audio.sinkLabel) return '';
    if (sinkCache && sinkCache.label === audio.sinkLabel) return sinkCache.id;
    const devs = await navigator.mediaDevices.enumerateDevices();
    const d = devs.find((x) => x.kind === 'audiooutput' && x.label === audio.sinkLabel);
    sinkCache = { label: audio.sinkLabel, id: d ? d.deviceId : '' };
    return sinkCache.id;
  }
  async function applySink(el) {
    // Uscita predefinita e mai cambiata: niente da fare (prima si reimpostava a ogni brano, rallentando l'avvio)
    if (!audio.sinkLabel && !el.sinkId) return;
    try {
      const id = await sinkId();
      if (el.sinkId !== id) await el.setSinkId(id);
    } catch {}
  }
  async function sendDevices() {
    try {
      const devs = await navigator.mediaDevices.enumerateDevices();
      const outs = devs.filter((d) => d.kind === 'audiooutput' && d.deviceId !== 'default' && d.deviceId !== 'communications').map((d) => d.label);
      send('devices', outs);
      return outs;
    } catch { return []; }
  }
  // Cuffie scollegate: se spariscono uscite audio durante la riproduzione, pausa
  let outputCount = null;
  navigator.mediaDevices.addEventListener('devicechange', async () => {
    sinkCache = null;
    const outs = await sendDevices();
    if (audio.pauseOnUnplug && mk && mk.isPlaying && outputCount !== null && outs.length < outputCount) mk.pause();
    outputCount = outs.length;
    mediaEls.forEach(applySink);
    apApplySink();
  });

  // Dissolvenza del volume su play/pausa comandati da Beats
  async function fadeTo(target, ms) {
    const from = mk.volume, steps = Math.max(1, Math.round(ms / 25));
    for (let i = 1; i <= steps; i++) { mk.volume = from + (target - from) * (i / steps); await sleep(ms / steps); }
  }
  async function playPause() {
    if (!audio.fadeMs) return mk.isPlaying ? mk.pause() : mk.play();
    if (mk.isPlaying) {
      const vol = mk.volume;
      await fadeTo(0, audio.fadeMs);
      await mk.pause();
      mk.volume = vol;
    } else {
      const vol = mk.volume;
      mk.volume = 0;
      await mk.play();
      await fadeTo(vol, audio.fadeMs);
    }
  }

  // Con le viste di Beats attive, Brani/Album/Artisti si aprono al clic senza far caricare prima la lista di Apple
  let libraryViews = false;
  let quietOn = false;
  // Si fermano solo le animazioni continue: quelle di ingresso, fermate a metà, lascerebbero titoli e copertine invisibili
  const pausedLoops = new Set();
  function pauseLoops() {
    if (!quietOn) {
      for (const a of pausedLoops) a.play();
      pausedLoops.clear();
      return;
    }
    for (const a of document.getAnimations()) {
      if (a.playState === 'running' && a.effect && a.effect.getComputedTiming().iterations === Infinity) {
        a.pause();
        pausedLoops.add(a);
      }
    }
  }

  window.__aria = {
    // Sposta Apple Music su un indirizzo senza ricaricarla: il suo router, davanti a una voce di cronologia che non
    // conosce, carica la pagina dall'indirizzo. Se l'app non è ancora in piedi risponde false e ricarica chi ha chiamato
    go(url) {
      const u = new URL(url, location.href);
      if (u.origin !== location.origin || !document.querySelector('nav a[href]')) return false;
      if (u.pathname === '/') {
        const home = document.querySelector('nav a[href$="/home"]');
        if (!home) return false;
        if (!location.pathname.endsWith('/home')) home.click();
        return true;
      }
      if (u.pathname !== location.pathname) {
        const state = { id: `beats-${Date.now()}` };
        history.pushState(state, '', u.pathname + u.search);
        dispatchEvent(new PopStateEvent('popstate', { state }));
      }
      return true;
    },
    libraryViews(on) { libraryViews = !!on; },
    // Beats non in primo piano: ferme le animazioni della pagina, le copertine video e le barre del lettore; la musica no
    quiet(on) {
      quietOn = !!on;
      window.__beatsMaxFps = quietOn ? 12 : 0;
      document.documentElement.classList.toggle('beats-quiet', quietOn);
      pauseLoops();
      for (const v of document.querySelectorAll('main video')) { if (quietOn) v.pause(); else v.play().catch(() => {}); }
      playerLoops();
    },
    // Una vista di Beats è aperta accanto alla barra laterale: la barra segna quella e il resto della pagina si ferma
    sideView(view) {
      document.documentElement.classList.toggle('beats-side-view', !!view);
      document.documentElement.classList.remove('beats-account-menu');
      // Della pagina si vede solo la barra: i menu di Apple aperti da lì (quello dell'account) devono restarci dentro
      const nav = view && document.querySelector('nav.navigation');
      if (nav) document.documentElement.style.setProperty('--beats-side-w', `${Math.round(nav.getBoundingClientRect().width)}px`);
      document.querySelector('nav a.beats-side-active')?.classList.remove('beats-side-active');
      if (view) document.querySelector(`nav a[href$="/library/${view}"]`)?.classList.add('beats-side-active');
    },
    closePlayer() {
      (document.querySelector('[data-testid="lyrics-fullscreen-modal"] .close-button, [data-testid="lyrics-fullscreen-modal"] button[aria-label*="Chiudi"]')
        || (document.documentElement.classList.contains('beats-mini-open') ? document.querySelector('#now-playing-dialog [data-testid="sliding-modal-collapse"]') : null))?.click();
    },
    audio(opts) {
      Object.assign(audio, { fadeMs: opts.fadeMs, sinkLabel: opts.sinkLabel, pauseOnUnplug: opts.pauseOnUnplug });
      if (!mk) return;
      mk.bitrate = opts.quality === 'standard' ? MusicKit.PlaybackBitrate.STANDARD : MusicKit.PlaybackBitrate.HIGH;
      try { mk.autoplayEnabled = !!opts.autoplay; } catch {}
      mediaEls.forEach(applySink);
      apApplySink();
    },
    setVolume(v) { if (mk) mk.volume = v; },
    airplay(on) {
      if (ap.wanted === on) return;
      ap.wanted = on;
      document.getElementById('beats-airplay-btn')?.classList.toggle('on', on);
      airplayRoute();
    },

    // Timer di spegnimento: abbassa piano il volume, mette in pausa e rimette il volume di prima
    async fadeOutAndPause(ms) {
      if (!mk || fadeState) return;
      fadeState = { vol: mk.volume, cancelled: false };
      const steps = Math.max(1, Math.round(ms / 100));
      for (let i = 1; i <= steps && !fadeState.cancelled; i++) {
        mk.volume = fadeState.vol * (1 - i / steps);
        await sleep(ms / steps);
      }
      if (!fadeState.cancelled) await mk.pause();
      mk.volume = fadeState.vol;
      fadeState = null;
    },
    cancelFade() { if (fadeState) fadeState.cancelled = true; },

    // Preferito ("cuore") per il brano in ascolto
    async love() {
      const it = mk && mk.nowPlayingItem;
      if (!it) return 'nessuno';
      const pp = (it.attributes && it.attributes.playParams) || it.playParams || {};
      const id = pp.catalogId || (String(it.id).startsWith('i.') ? null : it.id);
      if (!id) return 'non-catalogo';
      try {
        await mk.api.music(`/v1/me/favorites`, { 'ids[songs]': id }, { fetchOptions: { method: 'POST' } });
      } catch {
        await mk.api.music(`/v1/me/ratings/songs/${id}`, {}, {
          fetchOptions: { method: 'PUT', body: JSON.stringify({ type: 'rating', attributes: { value: 1 } }) },
        });
      }
      return it.title;
    },

    // Ricerca rapida: catalogo Apple Music + la tua libreria
    async search(q) {
      const sf = mk.storefrontId || 'it';
      const pick = (r) => (r.status === 'fulfilled' ? r.value.data.results || {} : {});
      const [cat, lib] = await Promise.allSettled([
        mk.api.music(`/v1/catalog/${sf}/search`, { term: q, types: 'songs,albums,artists,playlists', limit: 4 }),
        mk.api.music('/v1/me/library/search', { term: q, types: 'library-songs,library-albums,library-playlists', limit: 3 }),
      ]);
      const out = [];
      const add = (group, kind, label, source) => {
        for (const d of (group && group.data) || []) {
          const a = d.attributes || {};
          out.push({
            kind, label, source, id: d.id, type: d.type,
            title: a.name || '',
            subtitle: a.artistName || a.curatorName || (kind === 'artist' ? 'Artista' : ''),
            art: a.artwork && a.artwork.url ? a.artwork.url.replace('{w}', 96).replace('{h}', 96).replace('{f}', 'jpg') : '',
            url: a.url || '',
          });
        }
      };
      const l = pick(lib), c = pick(cat);
      add(l['library-songs'], 'song', 'Brano', 'Libreria');
      add(l['library-albums'], 'album', 'Album', 'Libreria');
      add(l['library-playlists'], 'playlist', 'Playlist', 'Libreria');
      add(c.songs, 'song', 'Brano', 'Apple Music');
      add(c.albums, 'album', 'Album', 'Apple Music');
      add(c.artists, 'artist', 'Artista', 'Apple Music');
      add(c.playlists, 'playlist', 'Playlist', 'Apple Music');
      return out;
    },
    async playItem(kind, id) {
      const key = { song: 'song', album: 'album', playlist: 'playlist' }[kind];
      if (key) await mk.setQueue({ [key]: id, startPlaying: true });
    },

    // Libreria per le viste di Beats: album dal più recente aggiunto, artisti con i loro id
    async libraryAlbums() {
      const page = (offset) => mk.api.music('/v1/me/library/albums', { limit: 100, offset, sort: '-dateAdded' });
      const first = await page(0);
      const total = (first.data.meta && first.data.meta.total) || first.data.data.length;
      const rest = [];
      for (let offset = 100; offset < total; offset += 100) rest.push(page(offset));
      const pages = [first, ...(await Promise.all(rest))];
      return pages.flatMap((p) => p.data.data).map((d) => {
        const a = d.attributes || {};
        return {
          id: d.id, title: a.name || '', artist: a.artistName || '', count: a.trackCount || 0,
          art: a.artwork && a.artwork.url ? a.artwork.url.replace('{w}', 300).replace('{h}', 300).replace('{f}', 'jpg') : '',
        };
      });
    },
    async artistUrl(id) {
      const r = await mk.api.music(`/v1/me/library/artists/${id}`, { include: 'catalog' });
      const d = r.data.data[0];
      const cat = d && d.relationships && d.relationships.catalog && d.relationships.catalog.data[0];
      return (cat && cat.attributes && cat.attributes.url) || null;
    },
    async libraryArtists() {
      const page = (offset) => mk.api.music('/v1/me/library/artists', { limit: 100, offset });
      const first = await page(0);
      const total = (first.data.meta && first.data.meta.total) || first.data.data.length;
      const rest = [];
      for (let offset = 100; offset < total; offset += 100) rest.push(page(offset));
      const pages = [first, ...(await Promise.all(rest))];
      return pages.flatMap((p) => p.data.data).map((d) => ({ id: d.id, name: (d.attributes && d.attributes.name) || '' }));
    },
    // Layout del lettore grande a schermo intero (copertina sfumata al centro, testi a destra)
    setFs(on) {
      fsOn = !!on;
      document.documentElement.classList.toggle('beats-fs', fsOn);
      // La copertina scivola tra centro e sinistra solo dopo l'ingresso nello schermo intero (vedi page.css)
      document.documentElement.classList.remove('beats-art-glide');
      clearTimeout(glideTimer);
      if (fsOn) glideTimer = setTimeout(() => { if (fsOn) document.documentElement.classList.add('beats-art-glide'); }, 1000);
      paintFsButton();
      requestAnimationFrame(() => requestAnimationFrame(placeQueueButton));
      setTimeout(placeQueueButton, 500);
    },
    outputs() { return [...mediaEls].map((e) => `${e.tagName}:${e.sinkId || 'default'}`); }, // diagnostica
    vizInfo() { return { grafo: !!ap.analyser, contesto: ap.ctx ? ap.ctx.state : 'nessuno', ritardoMs: Math.round(vizLatency() * 1000), colpi: viz.beats, bpm: viz.period ? Math.round(60 / viz.period) : 0, livelli: viz.lb.map((v) => +v.toFixed(2)) }; }, // diagnostica
    cmd(name, arg) {
      if (!mk) return;
      switch (name) {
        case 'playPause': playPause(); break;
        case 'next': mk.skipToNextItem(); break;
        case 'prev': mk.currentPlaybackTime > 3 ? mk.seekToTime(0) : mk.skipToPreviousItem(); break;
        case 'seek': if (mk.currentPlaybackDuration) mk.seekToTime(arg * mk.currentPlaybackDuration); break;
        case 'shuffle': mk.shuffleMode = mk.shuffleMode ? 0 : 1; send('playback', playback()); break;
        case 'repeat': mk.repeatMode = ((mk.repeatMode || 0) + 1) % 3; send('playback', playback()); break;
        case 'volume': mk.volume = Math.max(0, Math.min(1, Number(arg) || 0)); break;
      }
    },
    // Tutti i brani della libreria, dal più recente aggiunto (ordine fornito dal server di Apple)
    async librarySongs() {
      const page = (offset) => mk.api.music('/v1/me/library/songs', { limit: 100, offset, sort: '-dateAdded' });
      const first = await page(0);
      const total = (first.data.meta && first.data.meta.total) || first.data.data.length;
      const rest = [];
      for (let offset = 100; offset < total; offset += 100) rest.push(page(offset));
      const pages = [first, ...(await Promise.all(rest))];
      const songs = [];
      for (const p of pages) {
        for (const s of p.data.data) {
          const a = s.attributes || {};
          songs.push({
            id: s.id,
            title: a.name || '',
            artist: a.artistName || '',
            album: a.albumName || '',
            ms: a.durationInMillis || 0,
            art: a.artwork && a.artwork.url ? a.artwork.url.replace('{w}', 80).replace('{h}', 80).replace('{f}', 'jpg') : null,
          });
        }
      }
      return songs;
    },
    // Impronta della libreria: se non cambia, i brani salvati sul disco sono ancora giusti
    async libraryHead(kind) {
      const r = await mk.api.music(`/v1/me/library/${kind}`, { limit: 1, sort: '-dateAdded' });
      const first = r.data.data[0];
      return `${(r.data.meta && r.data.meta.total) || 0}|${first ? first.id : ''}`;
    },
    // Parte subito con il brano scelto: chiedere ad Apple i dati di tutta la coda prima di suonare costa più di
    // un secondo. Gli altri si aggiungono dopo, a musica partita (se nel frattempo se ne sceglie un altro, niente)
    async playSongs(ids, shuffle) {
      const gen = ++playGen;
      const list = ids.slice();
      if (shuffle) for (let i = list.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [list[i], list[j]] = [list[j], list[i]]; }
      mk.shuffleMode = shuffle ? 1 : 0;
      await mk.setQueue({ songs: list.slice(0, 1), startPlaying: true });
      if (list.length < 2) return;
      await sleep(1500);
      if (gen === playGen) await mk.playLater({ songs: list.slice(1) });
    },
    // Ogni modifica a :root ricalcola lo stile di tutta la pagina di Apple: si scrive solo ciò che è cambiato
    style(s) {
      const root = document.documentElement;
      const set = (k, v) => { v = String(v); if (styleCache[k] !== v) { styleCache[k] = v; root.style.setProperty(k, v); } };
      const data = (k, v) => { if (root.dataset[k] !== v) root.dataset[k] = v; };
      set('--aria-accent', s.accent);
      vizAccent = s.accent;
      set('--aria-nav-alpha', s.navAlpha);
      set('--aria-player-alpha', s.playerAlpha);
      set('--aria-radius', s.radius + 'px');
      set('--beats-radius', s.uiRadius + 'px');
      set('--beats-shadow', s.shadow);
      set('--beats-glass-alpha', s.glassAlpha);
      set('--beats-glass-blur', s.glassBlur + 'px');
      const icon = { white: ['#fff', '#1c1c1e'], accent: [s.accent, s.accent], muted: ['rgba(255,255,255,0.55)', 'rgba(0,0,0,0.5)'] }[s.navIcon];
      set('--beats-nav-icon', icon[0]);
      set('--beats-nav-icon-light', icon[1]);
      data('ariaFont', s.font);
      data('ariaHoverZoom', s.hoverZoom ? 'on' : 'off');
      data('viz', s.visualizer);
      playerLoops();
      root.classList.toggle('beats-glass', s.glassBlur > 0);
      root.classList.toggle('beats-shine', s.glassShine);
      root.classList.toggle('beats-lite-bg', s.liteBg);
      root.classList.toggle('beats-skin-cyber', s.skin === 'cyber');
      root.classList.toggle('beats-skin-gengy', s.skin === 'gengy');
      root.classList.toggle('beats-skin-steam', s.skin === 'steam');
      if (s.customFont) set('--beats-custom-font', `"${s.customFont.replace(/["\\]/g, '')}"`);
      root.classList.toggle('beats-custom-font', !!s.customFont);
      if (root.classList.contains('beats-nolyrics') === s.showLyrics) {
        flipColumn(() => root.classList.toggle('beats-nolyrics', !s.showLyrics), s.showLyrics);
        requestAnimationFrame(() => requestAnimationFrame(placeQueueButton)); // la colonna dei comandi si sposta
      }
      if (lyricsOn !== s.showLyrics || !document.querySelector('#beats-lyrics-btn svg')) paintLyricsButton(s.showLyrics);
      if (window.__beatsCovers !== s.animatedCovers) {
        window.__beatsCovers = s.animatedCovers;
        try { localStorage.setItem('beats-covers', s.animatedCovers ? '1' : '0'); } catch {}
        if (s.animatedCovers) for (const v of document.querySelectorAll('amp-ambient-video')) v.connectedCallback();
      }
    },
  };

  const hook = () => {
    try { mk = MusicKit.getInstance(); } catch { mk = null; }
    if (!mk) return setTimeout(hook, 500);
    send('ready', true);
    sendDevices().then((outs) => { outputCount = outs.length; });
    send('track', track());
    send('playback', playback());
    mk.addEventListener('nowPlayingItemDidChange', () => {
      send('track', track());
      refreshIfOpen();
      paintFsBackground();
      if (quietOn) setTimeout(pauseLoops, 1500); // il nuovo brano può far partire altre animazioni continue
    });
    mk.addEventListener('queueItemsDidChange', refreshIfOpen);
    mk.addEventListener('queuePositionDidChange', refreshIfOpen);
    mk.addEventListener('playbackStateDidChange', () => {
      send('playback', playback());
      document.documentElement.classList.toggle('beats-playing', !!mk.isPlaying);
      playerLoops();
    });
    let last = 0;
    for (const ev of ['shuffleModeDidChange', 'repeatModeDidChange', 'playbackVolumeDidChange']) {
      mk.addEventListener(ev, () => send('playback', playback()));
    }
    for (const ev of ['shuffleModeDidChange', 'repeatModeDidChange']) mk.addEventListener(ev, () => markToggles());
    mk.addEventListener('playbackVolumeDidChange', apGain);
    mk.addEventListener('playbackTimeDidChange', () => {
      const now = Date.now();
      if (now - last > 900) { last = now; send('playback', playback()); }
    });
  };

  // ---------- Coda e cronologia nel lettore grande ----------
  const Q = { open: false, tab: 'next', recent: [], recentAt: 0 };
  // Mentre testo e coda si scambiano si fermano barre e orologio del testo: ogni loro aggiornamento ricostruisce
  // i livelli della pagina e toglie fluidità. Per mezzo secondo non si nota
  const FLIP_MS = 480;
  let flipUntil = 0;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const info = (it) => {
    const a = it.attributes || {};
    const art = it.artwork || a.artwork;
    return {
      id: it.id,
      title: it.title || a.name || '',
      artist: it.artistName || a.artistName || '',
      art: art && art.url ? art.url.replace('{w}', 80).replace('{h}', 80).replace('{f}', 'jpg').replace('{c}', '') : '',
    };
  };
  const ICON = {
    queue: '<svg viewBox="0 0 24 24"><path d="M3 6h12M3 11h12M3 16h7"/><path d="M17 13v7.5"/><circle cx="15" cy="20" r="2"/><path d="M17 13l4-1.5"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z" fill="currentColor" stroke="none"/></svg>',
    next: '<svg viewBox="0 0 24 24"><path d="M4 7h10M4 12h10M4 17h6"/><path d="M18 20V9M15 12l3-3 3 3"/></svg>',
    last: '<svg viewBox="0 0 24 24"><path d="M4 7h10M4 12h10M4 17h6"/><path d="M18 9v11M15 17l3 3 3-3"/></svg>',
    remove: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    lyrics: '<svg viewBox="0 0 24 24"><path d="M4 5h16v11H9l-5 4z"/><path d="M8 9h8M8 12h5"/></svg>',
    expand: '<svg viewBox="0 0 24 24"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>',
    airplay: '<svg viewBox="0 0 24 24"><path d="M5.5 16.5a9 9 0 1 1 13 0"/><path d="M8.6 13.6a5 5 0 1 1 6.8 0"/><path d="M12 14.5 7.5 20h9z" fill="currentColor"/></svg>',
    shrink: '<svg viewBox="0 0 24 24"><path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/></svg>',
  };
  let fsOn = false;
  let glideTimer = 0;
  let vizAccent = '#ff6a8a'; // colore d'accento per il visualizzatore, tenuto qui: rileggerlo dallo stile 30 volte al secondo costava
  let playGen = 0;
  const VIZ_W = 1400, VIZ_H = 300; // tela del visualizzatore

  async function loadRecent(force) {
    if (!force && Date.now() - Q.recentAt < 60000) return;
    try {
      const r = await mk.api.music('/v1/me/recent/played/tracks', { limit: 30 });
      Q.recent = r.data.data.map(info);
      Q.recentAt = Date.now();
    } catch {}
  }

  // Riproduce subito un brano che non è nella coda: lo mette dopo quello attuale e ci salta
  async function playNow(id) {
    if (!mk.queue.length) return mk.setQueue({ songs: [id], startPlaying: true });
    await mk.playNext({ songs: [id] });
    await mk.skipToNextItem();
  }

  // Sposta un brano tra i prossimi (indici della coda); quelli già ascoltati e l'attuale non si toccano
  function moveInQueue(from, to) {
    const pos = mk.queue.position;
    if (from <= pos || to <= pos || from === to) return;
    const moved = mk.queue.spliceQueueItems(from, 1, []);
    mk.queue.spliceQueueItems(to, 0, moved);
  }

  async function queueAction(act, idx, id) {
    try {
      const pos = mk.queue.position;
      if (act === 'jump') await mk.changeToMediaAtIndex(idx);
      else if (act === 'remove') mk.queue.remove(idx);
      else if (act === 'up') moveInQueue(idx, pos + 1); // subito dopo il brano attuale
      else if (act === 'move') moveInQueue(idx, id);
      else if (act === 'now') await playNow(id);
      else if (act === 'after') await mk.playNext({ songs: [id] });
      else if (act === 'later') await mk.playLater({ songs: [id] });
    } catch (e) { console.warn('coda', e); }
    renderQueue();
  }

  function row(it, actions, opts = {}) {
    const btns = actions.map(([act, icon, title]) => `<button data-act="${act}" title="${title}">${ICON[icon]}</button>`).join('');
    return `<li class="${opts.now ? 'now' : ''}${opts.sortable ? ' up' : ''}" data-idx="${opts.idx ?? ''}" data-id="${esc(it.id)}">
      ${opts.sortable ? '<span class="grip" title="Trascina per spostare"><i></i><i></i><i></i></span>' : ''}
      ${it.art ? `<img src="${esc(it.art)}" alt="" draggable="false">` : '<span class="ph"></span>'}
      <div class="tx"><b>${esc(it.title)}</b><span>${esc(it.artist)}</span></div>
      <div class="ac">${btns}</div></li>`;
  }

  let drag = null;            // brano che si sta trascinando nella coda
  let renderAfterDrag = false;
  async function renderQueue() {
    const panel = document.getElementById('beats-queue');
    if (!panel || !mk) return;
    if (drag && drag.active) { renderAfterDrag = true; return; } // non ridisegnare sotto il dito
    panel.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === Q.tab));
    const list = panel.querySelector('ol');
    const items = mk.queue.items || [];
    const pos = mk.queue.position;
    let html = '';
    if (Q.tab === 'next') {
      if (items[pos]) html += `<h4>In riproduzione</h4>` + row(info(items[pos]), [], { now: true, idx: pos });
      const upcoming = items.map((it, i) => [it, i]).filter(([, i]) => i > pos);
      html += `<h4>Prossimi · ${upcoming.length}</h4>`;
      html += upcoming.map(([it, i]) => row(info(it), [['jump', 'play', 'Riproduci ora'], ['up', 'next', 'Sposta subito dopo'], ['remove', 'remove', 'Togli dalla coda']], { idx: i, sortable: true })).join('')
        || '<p class="empty">Nessun brano in coda dopo questo.</p>';
    } else {
      const played = items.map((it, i) => [it, i]).filter(([, i]) => i < pos).reverse();
      if (played.length) {
        html += `<h4>In questa sessione</h4>`;
        html += played.map(([it, i]) => row(info(it), [['jump', 'play', 'Riascolta ora'], ['after', 'next', 'Riproduci subito dopo'], ['later', 'last', 'Riproduci per ultimo']], { idx: i })).join('');
      }
      await loadRecent();
      html += `<h4>Ascoltati di recente</h4>`;
      html += Q.recent.map((it) => row(it, [['now', 'play', 'Riproduci ora'], ['after', 'next', 'Riproduci subito dopo'], ['later', 'last', 'Riproduci per ultimo']])).join('')
        || '<p class="empty">Nessun ascolto recente.</p>';
    }
    if (html !== list.drawn) { list.drawn = html; list.innerHTML = html; } // ridisegnare centinaia di righe blocca il giro della carta
  }
  // Nel lettore grande la coda è sempre pronta, anche chiusa: all'apertura non resta nulla da disegnare
  let queueIdle = 0;
  const prepareQueue = () => {
    if (queueIdle) return;
    queueIdle = requestIdleCallback(() => { queueIdle = 0; renderQueue(); }, { timeout: 1500 });
  };

  function deepFind(root, sel) {
    const inside = root.shadowRoot || root;
    const hit = inside.querySelector(sel);
    if (hit) return hit;
    for (const e of inside.querySelectorAll('*')) {
      if (e.shadowRoot) { const r = deepFind(e, sel); if (r) return r; }
    }
    return null;
  }

  // Pulsanti del lettore grande, dentro shadow root annidate dove lo stile della pagina non arriva: ci si mette uno stile
  // apposta. Ogni clic dà un piccolo rimbalzo con un lampo dell'icona; Casuale e Ripeti accesi hanno l'icona del colore
  // dell'accento (solo l'icona, senza cerchi), invece del grigio appena più chiaro di Apple
  let controlsSheet = null;
  const CONTROLS_CSS = `
    button { transition: transform 0.12s ease, color 0.2s ease, filter 0.2s ease; }
    button:active { transform: scale(0.82); }
    :host([data-beats-on]) button, [data-beats-on] button { color: var(--aria-accent) !important; }
    :host([data-beats-on]) button svg, [data-beats-on] button svg { fill: var(--aria-accent) !important; color: var(--aria-accent) !important;
      filter: drop-shadow(0 0 3px color-mix(in srgb, var(--aria-accent) 70%, transparent)); }
    button.beats-hit { animation: beatsHit 0.34s ease-out; }
    @keyframes beatsHit {
      0% { transform: scale(0.8); filter: brightness(1.9) drop-shadow(0 0 6px var(--aria-accent)); }
      55% { transform: scale(1.1); }
      100% { transform: scale(1); filter: none; }
    }`;
  const playerControls = () => document.querySelector('[data-testid="lyrics-fullscreen-modal"] apple-music-playback-controls');
  function styleControls() {
    const controls = playerControls();
    if (!controls) return;
    if (!controlsSheet) { controlsSheet = new CSSStyleSheet(); controlsSheet.replaceSync(CONTROLS_CSS); }
    const walk = (host) => {
      const inside = host.shadowRoot;
      if (inside && !inside.adoptedStyleSheets.includes(controlsSheet)) inside.adoptedStyleSheets = [...inside.adoptedStyleSheets, controlsSheet];
      for (const e of (inside || host).querySelectorAll('*')) if (e.shadowRoot) walk(e);
    };
    walk(controls);
    markToggles();
  }
  function markToggles() {
    const controls = playerControls();
    if (!controls || !mk) return;
    const shuffle = deepFind(controls, 'amp-playback-controls-shuffle'), repeat = deepFind(controls, 'amp-playback-controls-repeat');
    if (shuffle) shuffle.toggleAttribute('data-beats-on', !!mk.shuffleMode);
    if (repeat) repeat.toggleAttribute('data-beats-on', !!mk.repeatMode);
  }
  function hitButton(e) {
    const b = e.composedPath().find((n) => n.tagName === 'BUTTON');
    if (!b) return;
    b.classList.remove('beats-hit');
    void b.offsetWidth; // riparte anche con clic ravvicinati
    b.classList.add('beats-hit');
    b.addEventListener('animationend', () => b.classList.remove('beats-hit'), { once: true });
  }

  let flipping = 0; // colonna in scivolata: i pulsanti sono già al posto finale, misurarli ora li sposterebbe a metà strada
  // Dietro la colonna dei comandi del lettore grande l'effetto si attenua (maschera in page.css): qui se ne misura la
  // fascia. I pulsanti di Beats stanno dentro la colonna, quindi basta lei
  function placeVizShade() {
    const box = document.getElementById('beats-viz');
    const col = document.querySelector('[data-testid="lyrics-fullscreen-modal"] .lyrics__controls');
    if (!box) return;
    const r = col && col.getBoundingClientRect();
    if (!r || !r.width) { box.classList.remove('beats-shade'); return; }
    box.style.setProperty('--beats-shade-l', `${Math.round(r.left)}px`);
    box.style.setProperty('--beats-shade-r', `${Math.round(r.right)}px`);
    box.classList.add('beats-shade');
  }

  function placeQueueButton() {
    if (flipping) return;
    placeVizShade();
    const btn = document.getElementById('beats-queue-btn');
    const controls = document.querySelector('[data-testid="lyrics-fullscreen-modal"] apple-music-playback-controls');
    if (!btn || !controls) return;
    const fs = document.getElementById('beats-fs-btn');
    const ly = document.getElementById('beats-lyrics-btn');
    const air = document.getElementById('beats-airplay-btn');
    // AirPlay sta subito a sinistra del pulsante shuffle, che è in una shadow root annidata
    const placeAirplay = (size, mid) => {
      if (!air) return;
      const box = controls.getBoundingClientRect();
      const shuffle = deepFind(controls, 'amp-playback-controls-shuffle');
      const left = shuffle && shuffle.getBoundingClientRect().width ? shuffle.getBoundingClientRect().left : box.left + box.width / 2 - 140;
      air.style.left = `${Math.round(left - size - 10)}px`;
      air.style.top = `${Math.round(mid - size / 2)}px`;
    };
    // A schermo intero i pulsanti di Beats stanno in fondo alla barra dei comandi
    const bar = fsOn && document.querySelector('[data-testid="lyrics-fullscreen-modal"] .lyrics__controls');
    if (bar) {
      const b = bar.getBoundingClientRect();
      const top = `${Math.round(b.top + b.height / 2 - 16)}px`;
      [[ly, 140], [btn, 98], [fs, 56]].forEach(([el, off]) => { if (el) { el.style.left = `${Math.round(b.right - off)}px`; el.style.top = top; } });
      placeAirplay(32, b.top + b.height / 2);
      return;
    }
    const r = controls.getBoundingClientRect();
    // Allinea al centro dei pulsanti veri (play, avanti...), anche se stanno in una shadow root
    const root = controls.shadowRoot || controls;
    const rects = [...root.querySelectorAll('button')].map((b) => b.getBoundingClientRect()).filter((b) => b.width > 0);
    const right = r.right; // alcuni pulsanti stanno in shadow root annidate: il bordo destro lo dà il contenitore
    const mid = rects.length ? rects.reduce((s, b) => s + b.top + b.height / 2, 0) / rects.length : r.top + r.height / 2;
    btn.style.left = `${Math.round(right + 14)}px`;
    btn.style.top = `${Math.round(mid - 19)}px`;
    placeAirplay(38, mid);
    if (fs) { fs.style.left = `${Math.round(right + 60)}px`; fs.style.top = btn.style.top; }
    if (ly) { ly.style.left = `${Math.round(right + 106)}px`; ly.style.top = btn.style.top; }
  }

  // In finestra la colonna di copertina e comandi cambia posto (testo acceso o spento, coda aperta in un brano senza
  // testo): invece di saltare scivola nel posto nuovo, con i pulsanti di Beats. Solo transform, lo fa la scheda video.
  // A schermo intero ci pensa il CSS (la copertina è già posizionata con transform)
  function flipColumn(change, lyricsIn) {
    const modal = document.querySelector('[data-testid="lyrics-fullscreen-modal"]');
    const col = !fsOn && modal && modal.querySelector('.lyrics__controls');
    if (!col) { change(); return; }
    const before = col.getBoundingClientRect();
    change();
    placeQueueButton(); // i pulsanti vanno subito al posto finale, e da lì scivolano insieme alla colonna
    const after = col.getBoundingClientRect();
    const dx = before.left - after.left, dy = before.top - after.top;
    if (Math.abs(dx) > 1 || Math.abs(dy) > 1) {
      const frames = [{ transform: `translate3d(${dx}px, ${dy}px, 0)` }, { transform: 'none' }];
      const opts = { duration: 560, easing: 'cubic-bezier(.16, 1, .3, 1)' };
      flipping++;
      const end = () => { flipping = Math.max(0, flipping - 1); placeQueueButton(); };
      col.animate(frames, opts).finished.then(end, end);
      for (const id of ['beats-queue-btn', 'beats-fs-btn', 'beats-lyrics-btn', 'beats-airplay-btn']) document.getElementById(id)?.animate(frames, opts);
    }
    // Il testo che torna entra in dissolvenza dal lato, invece di comparire di colpo
    const ly = lyricsIn && modal.querySelector('.lyrics__lyrics');
    if (ly) ly.animate([{ opacity: 0, transform: 'translate3d(40px, 0, 0)' }, { opacity: 1, transform: 'none' }], { duration: 500, delay: 90, easing: 'cubic-bezier(.16, 1, .3, 1)', fill: 'backwards' });
  }

  let lyricsOn = true;
  function paintLyricsButton(on) {
    lyricsOn = on;
    playerLoops();
    const b = document.getElementById('beats-lyrics-btn');
    if (!b) return;
    b.innerHTML = ICON.lyrics;
    b.classList.toggle('on', on);
    b.title = on ? 'Nascondi il testo' : 'Mostra il testo';
  }

  // Sfondo leggero: la copertina attuale, sfocata dal CSS una volta sola
  function paintFsBackground() {
    const it = mk && mk.nowPlayingItem;
    if (!it) return;
    const art = info(it).art.replace('80x80', '400x400');
    if (art) for (const bg of document.querySelectorAll('#beats-fs-bg, .beats-cover-bg')) bg.style.backgroundImage = `url("${art}")`;
  }

  function paintFsButton() {
    const fs = document.getElementById('beats-fs-btn');
    if (!fs) return;
    fs.innerHTML = fsOn ? ICON.shrink : ICON.expand;
    fs.title = fsOn ? 'Esci dallo schermo intero (Esc)' : 'Schermo intero senza bordi';
    fs.classList.toggle('on', fsOn);
  }

  function setupQueueUi(modal) {
    if (document.getElementById('beats-queue-btn')) return;
    const btn = document.createElement('button');
    btn.id = 'beats-queue-btn';
    btn.title = 'Coda e cronologia';
    btn.innerHTML = ICON.queue;
    const panel = document.createElement('aside');
    panel.id = 'beats-queue';
    panel.innerHTML = `<header><div class="tabs"><button data-tab="next">Coda</button><button data-tab="history">Cronologia</button></div>
      <button class="x" title="Chiudi">${ICON.remove}</button></header><ol></ol>`;
    const fsBtn = document.createElement('button');
    fsBtn.id = 'beats-fs-btn';
    fsBtn.onclick = (e) => { e.stopPropagation(); send('fsToggle', true); };
    const lyBtn = document.createElement('button');
    lyBtn.id = 'beats-lyrics-btn';
    // Con la coda aperta il pulsante del testo rigira la carta sul testo; altrimenti mostra/nasconde il testo
    lyBtn.onclick = (e) => {
      e.stopPropagation();
      if (Q.open) { toggle(false); if (!lyricsOn) send('lyricsToggle', true); }
      else send('lyricsToggle', true);
    };
    const airBtn = document.createElement('button');
    airBtn.id = 'beats-airplay-btn';
    airBtn.title = 'AirPlay: ascolta su HomePod e Apple TV';
    airBtn.innerHTML = ICON.airplay;
    airBtn.classList.toggle('on', ap.wanted);
    airBtn.onclick = (e) => { e.stopPropagation(); send('airplayMenu', true); };
    const bg = document.createElement('div');
    bg.id = 'beats-fs-bg';
    const viz = document.createElement('div');
    viz.id = 'beats-viz';
    viz.innerHTML = `<canvas width="${VIZ_W}" height="${VIZ_H}"></canvas>`;
    const glow = document.createElement('div');
    glow.id = 'beats-glow';
    modal.prepend(bg, glow, viz);
    modal.append(airBtn, lyBtn, btn, fsBtn, panel);
    paintFsButton();
    paintLyricsButton(lyricsOn);
    paintFsBackground();

    panel.inert = true; // chiusa resta pronta sullo schermo, ma non si raggiunge né col mouse né da tastiera
    const toggle = (open) => {
      Q.open = open;
      flipUntil = performance.now() + FLIP_MS;
      panel.inert = !open;
      panel.classList.toggle('open', open);
      btn.classList.toggle('on', open);
      // Solo senza testo la colonna dei comandi si sposta (in finestra scivolando): altrimenti non serve rimisurare
      // proprio durante il passaggio
      const moves = document.documentElement.classList.contains('beats-nolyrics') || modal.classList.contains('is-lyrics-off');
      if (moves) flipColumn(() => document.documentElement.classList.toggle('beats-queue-open', open));
      else document.documentElement.classList.toggle('beats-queue-open', open);
      if (open) {
        renderQueue();
        loadRecent(true).then(() => { if (Q.tab === 'history') renderQueue(); });
      }
      if (moves) requestAnimationFrame(() => requestAnimationFrame(placeQueueButton));
      playerLoops();
    };
    btn.onclick = (e) => { e.stopPropagation(); toggle(!Q.open); };
    panel.querySelector('.x').onclick = () => toggle(false);
    panel.querySelector('.tabs').onclick = (e) => {
      const t = e.target.closest('[data-tab]');
      if (t) { Q.tab = t.dataset.tab; renderQueue(); }
    };
    // Trascinamento dei prossimi brani: la riga segue il puntatore, le altre si scostano per farle posto
    const list = panel.querySelector('ol');
    let suppressClick = false;
    list.addEventListener('pointerdown', (e) => {
      const li = e.target.closest('li.up');
      if (!li || e.button !== 0 || e.target.closest('button')) return;
      const rows = [...list.querySelectorAll('li.up')];
      const rects = rows.map((r) => r.getBoundingClientRect());
      drag = {
        li, rows, from: rows.indexOf(li), to: rows.indexOf(li), startY: e.clientY, startScroll: list.scrollTop,
        rowH: rects.length > 1 ? rects[1].top - rects[0].top : rects[0].height, active: false, id: e.pointerId,
      };
    });
    list.addEventListener('pointermove', (e) => {
      if (!drag || e.pointerId !== drag.id) return;
      const dy = e.clientY - drag.startY + (list.scrollTop - drag.startScroll);
      if (!drag.active) {
        if (Math.abs(dy) < 6) return;
        drag.active = true;
        drag.li.setPointerCapture(e.pointerId);
        drag.li.classList.add('dragging');
        list.classList.add('sorting');
      }
      drag.li.style.transform = `translate3d(0, ${dy}px, 0) scale(1.02)`;
      const to = Math.max(0, Math.min(drag.rows.length - 1, drag.from + Math.round(dy / drag.rowH)));
      if (to !== drag.to) {
        drag.to = to;
        drag.rows.forEach((r, k) => {
          if (r === drag.li) return;
          let shift = 0;
          if (drag.from < to && k > drag.from && k <= to) shift = -drag.rowH;
          if (drag.from > to && k >= to && k < drag.from) shift = drag.rowH;
          r.style.transform = shift ? `translate3d(0, ${shift}px, 0)` : '';
        });
      }
      // Vicino ai bordi la lista scorre da sola
      const box = list.getBoundingClientRect();
      if (e.clientY < box.top + 50) list.scrollTop -= 12;
      else if (e.clientY > box.bottom - 50) list.scrollTop += 12;
    });
    const endDrag = () => {
      if (!drag) return;
      const d = drag;
      drag = null;
      if (!d.active) return;
      suppressClick = true;
      setTimeout(() => { suppressClick = false; }, 50);
      list.classList.remove('sorting');
      d.li.classList.remove('dragging');
      d.rows.forEach((r) => { r.style.transform = ''; });
      if (d.to !== d.from) queueAction('move', +d.li.dataset.idx, +d.rows[d.to].dataset.idx);
      else if (renderAfterDrag) renderQueue();
      renderAfterDrag = false;
    };
    list.addEventListener('pointerup', endDrag);
    list.addEventListener('pointercancel', endDrag);

    list.onclick = (e) => {
      if (suppressClick) return;
      const b = e.target.closest('button[data-act]');
      const li = e.target.closest('li');
      if (!li) return;
      const idx = li.dataset.idx === '' ? -1 : +li.dataset.idx;
      if (b) return queueAction(b.dataset.act, idx, li.dataset.id);
      // clic sulla riga: riproduci
      if (li.classList.contains('now')) return;
      queueAction(idx >= 0 ? 'jump' : 'now', idx, li.dataset.id);
    };
    const controls = modal.querySelector('apple-music-playback-controls');
    if (controls) new ResizeObserver(placeQueueButton).observe(controls);
    // Stile dei pulsanti di Apple: le loro shadow root nascono un po' dopo, si ripassa
    requestAnimationFrame(styleControls);
    setTimeout(styleControls, 600);
    setTimeout(styleControls, 2000);
    modal.addEventListener('pointerdown', hitButton, true);
    // Apple toglie o rimette la colonna del testo (brano senza testo, testo riacceso): la colonna dei comandi passa dal
    // centro a sinistra senza cambiare misura, e i pulsanti di Beats la devono seguire
    let lyricsOff = modal.classList.contains('is-lyrics-off');
    new MutationObserver(() => {
      if (modal.classList.contains('is-lyrics-off') === lyricsOff) return;
      lyricsOff = !lyricsOff;
      requestAnimationFrame(() => requestAnimationFrame(placeQueueButton));
      setTimeout(placeQueueButton, 500);
    }).observe(modal, { attributes: true, attributeFilter: ['class'] });
    // Al prossimo fotogramma: misurare subito, appena inserito il lettore, obbligava a calcolarlo tutto in anticipo
    // (un blocco di decine di millisecondi proprio all'apertura)
    requestAnimationFrame(placeQueueButton);
    setTimeout(placeQueueButton, 400);
    if (Q.open) toggle(true);
    else prepareQueue();
  }
  window.addEventListener('resize', placeQueueButton);

  // Rotellina del mouse sul volume. L'ascolto si aggancia solo al controllo del volume, al primo passaggio del
  // puntatore: uno sulla finestra intera farebbe passare ogni scorrimento della pagina dal thread principale
  const VOLUME_STEP = 0.02;
  const wheelReady = new WeakSet();
  const onVolumeWheel = (e) => {
    e.preventDefault();
    if (!mk || !e.deltaY) return;
    mk.volume = Math.round(Math.min(1, Math.max(0, mk.volume + (e.deltaY < 0 ? VOLUME_STEP : -VOLUME_STEP))) * 100) / 100;
  };
  document.addEventListener('pointerover', (e) => {
    const el = e.target.closest && e.target.closest('.chrome-volume, amp-chrome-volume');
    if (!el || wheelReady.has(el)) return;
    wheelReady.add(el);
    el.addEventListener('wheel', onVolumeWheel, { passive: false });
  }, { passive: true });

  // A schermo intero Esc riporta in finestra: lo si intercetta prima di Apple, che chiude il lettore
  // al rilascio del tasto (keyup sul body). Va quindi fermato anche il keyup che segue.
  let swallowEscUp = false;
  window.addEventListener('keydown', (e) => {
    if (fsOn && e.key === 'Escape') {
      e.preventDefault();
      e.stopImmediatePropagation();
      swallowEscUp = true;
      send('fsExit', true);
    }
  }, true);
  window.addEventListener('keyup', (e) => {
    if (e.key === 'Escape' && (swallowEscUp || fsOn)) {
      e.preventDefault();
      e.stopImmediatePropagation();
      swallowEscUp = false;
    }
  }, true);
  // A schermo intero la barra spaziatrice è play/pausa, anche con un pulsante selezionato: fermando pure il rilascio
  // del tasto, quel pulsante non scatta. Tenendola premuta non si alterna a ripetizione
  const typing = (t) => t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
  for (const type of ['keydown', 'keyup']) {
    window.addEventListener(type, (e) => {
      if (!fsOn || e.code !== 'Space' || typing(e.composedPath()[0])) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      if (type === 'keydown' && !e.repeat && mk) playPause();
    }, true);
  }
  const refreshIfOpen = () => {
    if (Q.open) renderQueue();
    else if (document.getElementById('beats-queue')) prepareQueue();
  };

  // Cambio pagina: all'arrivo di ogni copertina Apple legge uno stile calcolato, che obbliga a ricalcolare gli stili
  // della pagina (decine di volte per pagina). Consegnando insieme, una volta per fotogramma, gli avvisi di caricamento
  // le letture dopo la prima non costano nulla: il ricalcolo scende da 600-700 a 120-150 ms
  const heldLoads = new Set(), ownLoads = new WeakSet();
  let loadFrame = 0;
  const flushLoads = () => {
    loadFrame = 0;
    const imgs = [...heldLoads];
    heldLoads.clear();
    for (const img of imgs) {
      const e = new Event('load');
      ownLoads.add(e);
      img.dispatchEvent(e);
    }
  };
  document.addEventListener('load', (e) => {
    const img = e.target;
    // Senza fotogrammi (finestra nascosta) l'avviso resterebbe fermo: passa subito
    if (ownLoads.has(e) || document.hidden || !(img instanceof HTMLImageElement) || !img.closest('main')) return;
    e.stopImmediatePropagation();
    heldLoads.add(img);
    if (!loadFrame) loadFrame = requestAnimationFrame(flushLoads);
  }, true);

  // Risposta immediata al clic sulla barra laterale: Apple cambia voce solo quando la pagina nuova è pronta
  const LIBRARY_LINK = /\/library\/(songs|albums|artists)\/?$/;
  let navTimer = 0, navLink = null, navCloseView = false;
  const navDone = () => {
    clearTimeout(navTimer);
    window.__beatsFastNav = false;
    document.documentElement.classList.remove('beats-navigating');
    if (navLink) navLink.classList.remove('beats-nav-pending');
    navLink = null;
  };
  document.addEventListener('click', (e) => {
    const a = e.target.closest && e.target.closest('nav a[href]');
    if (!a || e.button || e.ctrlKey || e.metaKey || e.shiftKey) return;
    // Il logo non porta da nessuna parte, nemmeno da tastiera (i clic da programma di go() invece passano)
    if (e.isTrusted && a.closest('.logo')) { e.preventDefault(); e.stopImmediatePropagation(); return; }
    const pathname = new URL(a.href, location.href).pathname;
    const library = libraryViews && pathname.match(LIBRARY_LINK);
    if (library) {
      e.preventDefault();
      e.stopImmediatePropagation();
      send('libraryNav', library[1]);
      return;
    }
    const inSideView = document.documentElement.classList.contains('beats-side-view');
    if (pathname === location.pathname) { if (inSideView) send('libraryNav', null); return; }
    navCloseView = inSideView; // la vista di Beats resta finché la pagina scelta non è pronta
    navDone();
    window.__beatsFastNav = /\/(home|library\/all-playlists|library\/recently-added|radio|new)\/?$/.test(pathname);
    navLink = a;
    navBefore = mainText();
    a.classList.add('beats-nav-pending');
    document.documentElement.classList.add('beats-navigating');
    navTimer = setTimeout(navDone, 8000); // Apple può anche non cambiare pagina (rete assente)
  }, true);
  // Voce di un menu di Apple scelta accanto a una vista di Beats (menu dell'account: Impostazioni apre una pagina,
  // Trasferisci musica una finestra al centro). Si aprono nella parte di Apple coperta dalla vista, quindi la vista si
  // chiude: con la pagina nuova (come per le voci della barra) o appena compare la finestra
  let menuTimer = 0;
  const openDialogs = () => [...document.querySelectorAll('dialog[open], [role="dialog"], [aria-modal="true"]')].filter((d) => d.getClientRects().length);
  document.addEventListener('click', (e) => {
    const root = document.documentElement;
    if (!root.classList.contains('beats-side-view') || !e.target.closest) return;
    // Il menu dell'account si apre sopra la sua scheda, allineato al bordo destro, invece che dal centro del pulsante
    // verso destra (oltre il bordo della barra, dove verrebbe tagliato)
    const trig = e.target.closest('.account-menu .contextual-menu__trigger');
    if (trig) {
      const r = trig.getBoundingClientRect();
      root.style.setProperty('--beats-account-right', `${Math.round(innerWidth - r.right)}px`);
      root.style.setProperty('--beats-account-bottom', `${Math.round(innerHeight - r.top + 6)}px`);
      root.classList.add('beats-account-menu');
      return;
    }
    if (!e.target.closest('amp-contextual-menu .contextual-menu li')) return;
    const before = new Set(openDialogs());
    navCloseView = true;
    clearTimeout(menuTimer);
    let tries = 0;
    const check = () => {
      if (!navCloseView) return; // la pagina è cambiata e la vista si è già chiusa
      if (openDialogs().some((d) => !before.has(d))) { navCloseView = false; send('libraryNav', null); return; }
      if (++tries < 16) menuTimer = setTimeout(check, 250);
      else navCloseView = false; // niente da mostrare qui (Aiuto si apre nel browser)
    };
    menuTimer = setTimeout(check, 250);
  }, true);
  document.addEventListener('pointerover', (e) => {
    if (e.target.closest && e.target.closest('nav a[href$="/home"]')) window.__beatsRefreshHome?.();
  }, true);
  // Difetto di Apple: se si clicca mentre la pagina di prima finisce di caricare, l'indirizzo cambia ma resta il vecchio
  // contenuto. Se dopo un attimo è ancora tutto uguale, si richiede la pagina al suo router, una volta sola
  const mainText = () => (document.querySelector('main')?.innerText || '').slice(0, 120);
  let navBefore = null;
  if (window.navigation) window.navigation.addEventListener('currententrychange', () => {
    const before = navBefore;
    navBefore = null;
    navDone();
    if (navCloseView) { navCloseView = false; send('libraryNav', null); }
    if (before === null) return;
    const path = location.pathname;
    setTimeout(() => {
      if (location.pathname !== path || mainText() !== before) return;
      const state = { id: `beats-${Date.now()}` };
      history.replaceState(state, '', location.pathname + location.search);
      dispatchEvent(new PopStateEvent('popstate', { state }));
    }, 800);
  });

  // Lettore a schermo intero di Apple (clic sulla copertina nel player): avvisa l'app per il vero schermo intero
  let fullOpen = false;
  // Ad ogni modifica della pagina (migliaia durante un cambio pagina) basta leggere la lunghezza di una
  // collezione "viva": costo quasi zero, invece di ricercare in tutto il documento
  const fullModals = document.getElementsByClassName('lyrics__container');
  function checkPlayer() {
    let modal = null;
    for (let i = 0; i < fullModals.length; i++) {
      if (fullModals[i].dataset.testid === 'lyrics-fullscreen-modal') { modal = fullModals[i]; break; }
    }
    if (modal) { setupQueueUi(modal); ensureLyrics(modal); }
    const mini = modal ? null : miniPlayer();
    document.documentElement.classList.toggle('beats-mini-open', !!mini);
    const open = !!modal || !!mini;
    if (open !== fullOpen) { fullOpen = open; send('fullplayer', open); playerLoops(); pageCovered(open); }
  }
  new MutationObserver(checkPlayer).observe(document.body, { childList: true, subtree: true });

  // Apple ricorda l'ultima vista del suo lettore (copertina, testo o coda) e la condivide con il lettore compatto delle
  // finestre strette: lasciato quello sulla copertina, il lettore grande si apriva senza testo. Se in Beats il testo è
  // acceso, all'apertura lo si riaccende con il pulsante "Testi" di Apple (nascosto: fa lo stesso quello di Beats)
  function ensureLyrics(modal) {
    if (!lyricsOn || modal.beatsLyricsAsked || !modal.classList.contains('is-lyrics-off')) return;
    const it = mk && mk.nowPlayingItem;
    if (it && it.attributes && it.attributes.hasLyrics === false) return; // brano senza testo: resta così
    const b = modal.querySelector('[data-testid="lyrics-button"]');
    if (!b) return;
    modal.beatsLyricsAsked = true; // una volta per apertura
    b.click();
  }

  // Lettore compatto di Apple, quello delle finestre strette (per esempio a metà schermo): un riquadro che sale dal
  // basso senza uno sfondo suo, quindi trasparente sopra la pagina, e sotto la barra laterale. Gli si dà la copertina
  // sfocata del lettore grande e lo si porta sopra a tutto. Il pannello laterale dei testi, più stretto, resta com'è
  const miniWatched = new WeakSet();
  function miniPlayer() {
    const dialog = document.getElementById('now-playing-dialog');
    const sheet = dialog && dialog.querySelector('.sliding-modal');
    if (!sheet) return null;
    if (!miniWatched.has(sheet)) {
      miniWatched.add(sheet);
      new MutationObserver(checkPlayer).observe(sheet, { attributes: true, attributeFilter: ['class'] }); // si chiude togliendo una classe
    }
    if (!sheet.classList.contains('is-open')) return null;
    // La misura solo all'apertura: mentre è aperto il testo cambia la pagina di continuo
    if (!document.documentElement.classList.contains('beats-mini-open') && sheet.getBoundingClientRect().width < innerWidth * 0.9) return null;
    const back = sheet.querySelector('.sliding-modal-backdrop');
    if (back && !back.querySelector('.beats-cover-bg')) {
      const bg = document.createElement('div');
      bg.className = 'beats-cover-bg';
      back.prepend(bg);
      paintFsBackground();
    }
    return sheet;
  }

  // Lettore grande aperto: la pagina sotto (Home, album...) è coperta del tutto e, finita l'animazione d'apertura, non
  // si calcola più. A ogni fotogramma del testo animato costava quasi quanto il lettore. Alla chiusura torna subito
  let coverTimer = 0;
  function pageCovered(on) {
    clearTimeout(coverTimer);
    if (on) coverTimer = setTimeout(() => { if (fullOpen) document.documentElement.classList.add('beats-page-covered'); }, 900);
    else document.documentElement.classList.remove('beats-page-covered');
  }
  // La chiusura ha la sua animazione, durante la quale la pagina sotto si rivede: la si ridisegna già al clic
  const uncover = () => {
    pageCovered(false);
    setTimeout(() => { if (fullOpen) pageCovered(true); }, 1500); // non si è chiuso (es. Esc esce solo dallo schermo intero)
  };
  document.addEventListener('click', (e) => {
    if (fullOpen && e.target.closest && e.target.closest('[data-testid="lyrics-fullscreen-modal"] .close-button, #now-playing-dialog [data-testid="sliding-modal-collapse"]')) uncover();
  }, true);
  document.addEventListener('keydown', (e) => { if (fullOpen && e.key === 'Escape') uncover(); }, true);

  // Testo sincronizzato. Il componente di Apple sceglie la riga dal tempo che riceve, arrotondato al secondo. Quando una
  // riga si accende le sue parole partono da un cronometro tutto loro (ognuna "data-delay" ms dopo quel momento) e nessuno
  // le riallinea più: tutta la riga resta sfasata quanto l'istante in cui si è accesa. Mentre il testo è a schermo gli si dà
  // il tempo vero, ogni riga si accende nel momento esatto con un timer preciso e, subito prima, i ritardi delle sue parole
  // si ricalcolano da quel momento. Il tempo arrotondato di Apple si ignora (riscriverlo farebbe tremare le righe)
  const CLOCK_PROP = 'currentPlaybackMillis';
  const APPLE_LEAD = 250; // Apple sceglie la riga di (tempo + 250 ms)
  const LINE_EARLY = { Word: 250, Line: 120 }; // quanto prima del canto si accende la riga, per farla arrivare in tempo
  const CLOCK_EVERY = 400; // tra una riga e l'altra serve solo ai puntini e ai salti: ogni aggiornamento ridisegna il testo
  // Dove sta il centro della riga corrente nel riquadro: nel terzo alto, lontana dagli effetti in fondo. Apple la manda a
  // una distanza dal bordo della finestra, non del riquadro, calcolata sull'altezza che il riquadro aveva quando si è
  // aperto: a schermo intero finiva sotto la sfumatura
  const TEXT_CENTER = 0.22;
  let clock = null, clockTimer = null;

  // La stessa scelta che fa Apple: l'ultima riga che contiene il tempo, altrimenti quella prima della prossima
  function lineAt(c, t) {
    let k = -1;
    c.lines.forEach((l, i) => { if (l.begin <= t && l.end >= t) k = i; });
    return k > 0 ? k : c.lines.findIndex((l) => t < l.begin) - 1;
  }
  // Punto dello schermo a cui deve arrivare il bordo alto della riga
  function lineTop(c, k) {
    const H = c.el.clientHeight, line = c.lines[k];
    const h = line ? line.node.getBoundingClientRect().height : 0;
    // La riga dei puntini si richiude dopo che la nuova riga è arrivata: si conta già lo spazio che verrà a mancare
    let folding = 0;
    for (let i = 0; i < k; i++) if (c.lines[i].fold) folding += c.lines[i].node.getBoundingClientRect().height;
    return c.el.getBoundingClientRect().top + Math.max(H * 0.12, H * TEXT_CENTER - h / 2) + folding;
  }
  // Spazio sopra e sotto il testo, per poter centrare anche la prima e l'ultima riga; si rimisura quando il riquadro cambia
  function textFit(c) {
    const H = c.el.clientHeight;
    if (!H) return;
    const top = `${Math.round(H * TEXT_CENTER)}px`, bottom = `${Math.round(H * (1 - TEXT_CENTER))}px`;
    if (H === c.H && c.top.style.height === top && c.bottom.style.height === bottom) return;
    c.H = H;
    c.top.style.setProperty('height', top, 'important');
    c.bottom.style.setProperty('height', bottom, 'important');
    const k = lineAt(c, c.get.call(c.el) + APPLE_LEAD), line = c.lines[k];
    if (line) c.el.scrollTop += line.node.getBoundingClientRect().top - lineTop(c, k);
  }
  function clockFind() {
    const host = document.querySelector('[data-testid="lyrics-fullscreen-modal"] amp-lyrics, #now-playing-dialog amp-lyrics');
    const el = host && deepFind(host, 'amp-lyrics-display-time-synced');
    if (!el || !el.shadowRoot) return null;
    let desc = null;
    for (let o = Object.getPrototypeOf(el); o && !desc; o = Object.getPrototypeOf(o)) desc = Object.getOwnPropertyDescriptor(o, CLOCK_PROP);
    const nodes = [...el.shadowRoot.querySelectorAll('amp-lyrics-display-synced-line')];
    const gaps = [...el.shadowRoot.children].filter((n) => n.tagName === 'DIV');
    if (!desc || !desc.set || !nodes.length || !nodes[0].line || gaps.length < 2) return null;
    const early = LINE_EARLY[el.lyrics && el.lyrics.timing] || LINE_EARLY.Line;
    const lines = nodes.map((node, i) => {
      const p = node.line.lineProps, before = i ? nodes[i - 1].line.lineProps : null;
      // Prima del suo momento solo se la riga precedente ha finito: altrimenti le sue ultime parole resterebbero a metà
      const room = before && !before.collapsible ? Math.max(0, p.begin - before.end) : early;
      return { node, begin: p.begin, end: p.end, on: p.begin - Math.min(early, room), fold: !!p.collapsible, first: p.words && p.words.length ? p.words[0].begin : p.begin };
    });
    const c = { el, set: desc.set, get: desc.get, lines, top: gaps[0], bottom: gaps[gaps.length - 1], line: -9, H: 0 };
    Object.defineProperty(el, CLOCK_PROP, { configurable: true, get() { return desc.get.call(el); }, set() {} });
    // Apple porta la riga a "altezza di questo spazio + 55 px" dal bordo della finestra: qui legge l'altezza, e la risposta
    // è quella che manda la riga al posto giusto del riquadro
    c.top.getBoundingClientRect = () => new DOMRect(0, 0, 0, lineTop(c, lineAt(c, desc.get.call(el) + APPLE_LEAD)) - 55);
    return c;
  }
  function clockRelease() {
    if (clock) delete clock.el[CLOCK_PROP];
    clock = null;
  }
  // Tempo dentro il brano. Quando un brano passa da solo al successivo l'audio resta sullo stesso orologio (il secondo brano
  // comincia per esempio a 245 s): si toglie il punto in cui è cominciato, come fa il lettore di MusicKit, che però fuori
  // dà solo i secondi interi. Se i due non vanno d'accordo vale il suo
  function trackMs(audio) {
    // (con le onde attive l'audio passa dal grafo e si sente un attimo dopo il tempo che il lettore dichiara)
    const delay = ap.src && !ap.wanted ? (ap.ctx.baseLatency || 0) + (ap.ctx.outputLatency || 0) : 0;
    const t = audio.currentTime - delay - ((window.mseBuffer && window.mseBuffer.currentTimestampOffset) || 0);
    const his = mk.currentPlaybackTime;
    return (Number.isFinite(his) && Math.abs(t - his) >= 1.5 ? his : t) * 1000;
  }
  // Fa il suo lavoro e dice fra quanti ms rifarlo
  function clockStep(audio) {
    if (performance.now() < flipUntil) return 60;
    if (audio.seeking) return 30; // salto nel brano: si riparte quando l'audio riparte
    if (!clock || !clock.el.isConnected) {
      clockRelease();
      clock = clockFind();
      if (!clock) return CLOCK_EVERY; // il testo del brano non è ancora pronto
    }
    textFit(clock);
    const now = trackMs(audio), lines = clock.lines;
    const next = lines.find((l) => l.on > now);
    // Il tempo vero, trattenuto solo quanto basta perché Apple non accenda la prossima riga prima del suo momento
    const given = next && now + APPLE_LEAD >= next.begin ? next.begin - APPLE_LEAD - 1 : now;
    const k = lineAt(clock, given + APPLE_LEAD);
    if (k !== clock.line) {
      clock.line = k;
      const line = lines[k];
      if (line) {
        for (const s of line.node.querySelectorAll('.syllable')) {
          if (s.beatsDelay === undefined) s.beatsDelay = parseInt(s.dataset.delay, 10);
          s.dataset.delay = Math.round(s.beatsDelay + line.first - now);
        }
      }
    }
    clock.set.call(clock.el, given);
    if (audio.paused) return 500;
    return next ? Math.max(1, Math.min(CLOCK_EVERY, next.on - now)) : CLOCK_EVERY;
  }
  function clockLoop(audio) {
    let wait = CLOCK_EVERY;
    try { wait = clockStep(audio); } catch {} // un errore nel componente di Apple non deve fermare l'orologio
    clockTimer = setTimeout(clockLoop, wait, audio);
  }
  function playerLoops() {
    const audio = document.getElementById('apple-music-player');
    if (audio && !audio.beatsSeekWatch) { audio.beatsSeekWatch = true; audio.addEventListener('seeked', playerLoops); }
    // Non in primo piano il testo resta all'orologio di Apple: si aggiorna molto meno spesso
    const run = !!audio && fullOpen && lyricsOn && !Q.open && !quietOn && !document.hidden && !!mk;
    clearTimeout(clockTimer);
    clockTimer = null;
    if (run) clockLoop(audio);
    else clockRelease();
    vizCheck();
  }

  document.addEventListener('visibilitychange', playerLoops);

  // Effetti a ritmo, scelti nelle impostazioni: onde, spettro, costellazione, matrice, linea, scintille, fuochi e aurora
  // sulla tela in basso, bagliore dietro la copertina. Tutti mossi dalla musica vera: i livelli di bassi, medi e acuti e i
  // colpi di batteria riconosciuti nel suono, con il tempo del brano. Il suono si sente un po' dopo che è stato ascoltato
  // (passa ancora dalla scheda audio, o va ad AirPlay): si disegna l'ascolto di quell'istante prima, così i colpi si vedono
  // quando si sentono. Una sola tela, circa 30 fotogrammi al secondo; a musica ferma si calmano e il disegno si ferma
  const VIZ_FRAME = 30, VIZ_POINTS = 72, VIZ_BARS = 36, VIZ_SPARKS = 240, VIZ_TRACE = 160, VIZ_SLOTS = 96, VIZ_ROWS = 9, VIZ_STARS = 64;
  const VIZ_CANVAS = new Set(['waves', 'spectrum', 'constellation', 'matrix', 'line', 'sparks', 'fireworks', 'aurora']);
  // Memoria degli ultimi 3 secondi di ascolto, per disegnarli quando si sentono
  const vizSlots = () => {
    const s = { t: new Float64Array(VIZ_SLOTS), bands: new Float32Array(VIZ_SLOTS * 3), pulse: new Float32Array(VIZ_SLOTS),
      bars: new Float32Array(VIZ_SLOTS * VIZ_BARS), trace: new Float32Array(VIZ_SLOTS * VIZ_TRACE), head: 0, count: 0, barsAt: [], traceAt: [] };
    for (let i = 0; i < VIZ_SLOTS; i++) {
      s.barsAt.push(s.bars.subarray(i * VIZ_BARS, (i + 1) * VIZ_BARS));
      s.traceAt.push(s.trace.subarray(i * VIZ_TRACE, (i + 1) * VIZ_TRACE));
    }
    return s;
  };
  const viz = { raf: 0, last: 0, phase: 0, tried: -1e9, bins: null, prev: null, wave: null, key: '', fill: [], line: [], mode: '',
    bands: [0, 0, 0], pulse: 0, barsIn: null, traceIn: null,         // quello che si disegna, nell'istante in cui si sente
    lb: [0, 0, 0], lp: 0, peak: [0.3, 0.3, 0.3], slot: vizSlots(),    // l'ascolto dal vivo
    fluxMean: 0, fluxDev: 0, lastBeat: -1e9, beats: 0, gaps: [], period: 0,
    amp: [3, 3, 3], up: new Float32Array(VIZ_POINTS + 1), down: new Float32Array(VIZ_POINTS + 1),
    ar: 1.2, canvas: null, ro: null, glow: 0, glowDriven: false };
  const VIZ_DRAW = { waves: drawWaves, spectrum: drawSpectrum, constellation: drawConstellation, matrix: drawMatrix, line: drawLine,
    sparks: drawSparks, fireworks: drawFireworks, aurora: drawAurora };
  function vizEdges() { // frequenze di ogni barra in scala logaritmica, da 43 Hz a 16 kHz
    if (viz.edges) return viz.edges;
    viz.edges = new Uint16Array(VIZ_BARS + 1);
    for (let i = 0; i <= VIZ_BARS; i++) viz.edges[i] = Math.max(i ? viz.edges[i - 1] + 1 : 1, Math.round(Math.pow(370, i / VIZ_BARS)));
    return viz.edges;
  }
  // Ascolto dal vivo: livelli di bassi, medi e acuti (con guadagno automatico) e colpi di batteria. Un colpo è un salto
  // improvviso di bassi (cassa) e medi (rullante) rispetto all'ascolto prima, molto sopra la media recente dei salti: la
  // soglia segue il brano. Dagli intervalli tra i colpi si ricava il tempo
  function vizListen(dt, playing, now, mode) {
    const a = ap.analyser, live = !!a && playing, S = viz.slot, near = (tau) => 1 - Math.exp(-dt / tau);
    let levels = [0, 0, 0], onset = 0;
    if (live) {
      if (!viz.bins || viz.bins.length !== a.frequencyBinCount) { viz.bins = new Uint8Array(a.frequencyBinCount); viz.prev = new Uint8Array(a.frequencyBinCount); }
      viz.prev.set(viz.bins);
      a.getByteFrequencyData(viz.bins);
      const b = viz.bins, p = viz.prev;
      const mean = (from, to) => { let s = 0; for (let i = from; i < to; i++) s += b[i]; return s / (to - from) / 255; };
      levels = [mean(1, 6), mean(6, 47), mean(47, 200)]; // circa fino a 250 Hz, fino a 2 kHz, fino a 8,6 kHz
      let low = 0, mid = 0;
      for (let i = 1; i < 8; i++) { const d = b[i] - p[i]; if (d > 0) low += d; }
      for (let i = 8; i < 64; i++) { const d = b[i] - p[i]; if (d > 0) mid += d; }
      onset = low / (7 * 255) + 0.4 * mid / (56 * 255);
    } else if (playing) { // senza accesso all'audio: un movimento lento, senza colpi inventati
      const t = now / 1000;
      levels = [0.35 + 0.1 * Math.sin(t * 1.1), 0.35 + 0.1 * Math.sin(t * 1.7), 0.25 + 0.08 * Math.sin(t * 2.3)];
    }
    levels.forEach((v, i) => {
      viz.peak[i] = Math.max(v, viz.peak[i] + (0.18 - viz.peak[i]) * near(9)); // canzoni piano o forte riempiono lo stesso spazio
      const level = Math.pow(Math.min(1, v / Math.max(0.12, viz.peak[i])), 1.6);
      viz.lb[i] += (level - viz.lb[i]) * near(level > viz.lb[i] ? 0.02 : 0.12);
    });
    const th = viz.fluxMean + 1.5 * viz.fluxDev + 0.01;
    viz.lp *= Math.exp(-dt / 0.17);
    if (live && onset > th && now - viz.lastBeat > 190) {
      viz.lp = Math.max(viz.lp, Math.min(1, 0.6 + 0.8 * (onset - th) / (th + 0.02)));
      const gap = (now - viz.lastBeat) / 1000;
      if (gap > 0.3 && gap < 1.2) {
        viz.gaps.push(gap);
        if (viz.gaps.length > 10) viz.gaps.shift();
        if (viz.gaps.length >= 4) { const g = viz.gaps.slice().sort((x, y) => x - y); viz.period = g[g.length >> 1]; }
      }
      viz.lastBeat = now;
      viz.beats++;
    }
    const k = near(1.2);
    viz.fluxDev += (Math.abs(onset - viz.fluxMean) - viz.fluxDev) * k;
    viz.fluxMean += (onset - viz.fluxMean) * k;
    // In memoria con l'ora, per disegnarlo quando si sente
    const i0 = S.head = (S.head + 1) % VIZ_SLOTS;
    S.count = Math.min(VIZ_SLOTS, S.count + 1);
    S.t[i0] = now;
    S.bands[i0 * 3] = viz.lb[0]; S.bands[i0 * 3 + 1] = viz.lb[1]; S.bands[i0 * 3 + 2] = viz.lb[2];
    S.pulse[i0] = viz.lp;
    const bars = S.barsAt[i0], edges = vizEdges();
    for (let i = 0; i < VIZ_BARS; i++) {
      let v = 0;
      if (live) {
        for (let j = edges[i]; j < edges[i + 1]; j++) if (viz.bins[j] > v) v = viz.bins[j];
        v = v / 255 * (0.8 + 0.5 * i / VIZ_BARS); // gli acuti hanno meno energia: un piccolo aiuto
      } else if (playing) {
        const u = i / VIZ_BARS;
        v = (viz.lb[0] * Math.max(0, 1 - u * 3) + viz.lb[1] * Math.max(0, 1 - Math.abs(u - 0.45) * 3) + viz.lb[2] * Math.max(0, 1 - Math.abs(u - 0.85) * 4))
          * (0.75 + 0.25 * Math.sin(i * 1.7 + now / 180));
      }
      bars[i] = v;
    }
    if (mode === 'line') {
      const out = S.traceAt[i0], n = VIZ_TRACE;
      if (live) {
        if (!viz.wave || viz.wave.length !== a.fftSize) viz.wave = new Uint8Array(a.fftSize);
        a.getByteTimeDomainData(viz.wave);
        const span = viz.wave.length >> 1;
        let start = 0; // parte da una salita per lo zero: così il disegno resta fermo invece di tremare
        for (let i = 1; i < span; i++) if (viz.wave[i - 1] < 128 && viz.wave[i] >= 128) { start = i; break; }
        for (let j = 0; j < n; j++) out[j] = (viz.wave[start + Math.floor(j * span / n)] - 128) / 128;
      } else {
        const t = now / 1000;
        for (let j = 0; j < n; j++) {
          const u = j / n;
          out[j] = playing ? 0.5 * viz.lb[0] * Math.sin(u * 19 + t * 5) + 0.3 * viz.lb[1] * Math.sin(u * 61 - t * 7) + 0.15 * viz.lb[2] * Math.sin(u * 151 + t * 11) : 0;
        }
      }
    }
  }
  // Quanto dopo si sente quello che si è appena ascoltato: l'uscita della scheda audio, oppure il ritardo di AirPlay
  function vizLatency() {
    if (!ap.ctx || !ap.src) return 0;
    if (ap.wanted) return AP_DELAY;
    return Math.min(0.5, (ap.ctx.baseLatency || 0) + (ap.ctx.outputLatency || 0));
  }
  // Si disegna l'ascolto di quell'istante prima
  function vizShow(now) {
    const S = viz.slot, want = now - vizLatency() * 1000;
    let i = S.head;
    for (let n = 1; n < S.count && S.t[i] > want; n++) i = (i - 1 + VIZ_SLOTS) % VIZ_SLOTS;
    viz.bands[0] = S.bands[i * 3]; viz.bands[1] = S.bands[i * 3 + 1]; viz.bands[2] = S.bands[i * 3 + 2];
    viz.pulse = S.pulse[i];
    viz.barsIn = S.barsAt[i];
    viz.traceIn = S.traceAt[i];
  }
  // Colori: quelli del tema, oppure l'accento con due compagni vicini sulla ruota dei colori
  function vizColors() {
    const c = document.documentElement.classList;
    if (c.contains('beats-skin-cyber')) return ['#fcee0a', '#00f0ff', '#ff003c'];
    if (c.contains('beats-skin-gengy')) return ['#b07bff', '#e8364f', '#f6f0ff'];
    if (c.contains('beats-skin-steam')) return ['#e3b866', '#c4743c', '#6fbfae'];
    const m = /^#([0-9a-f]{6})$/i.exec(vizAccent);
    if (!m) return [vizAccent, vizAccent, vizAccent];
    const n = parseInt(m[1], 16), r = (n >> 16 & 255) / 255, g = (n >> 8 & 255) / 255, b = (n & 255) / 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2, d = max - min, s = d ? d / (1 - Math.abs(2 * l - 1)) : 0;
    const h = !d ? 0 : max === r ? (((g - b) / d) % 6 + 6) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
    const tone = (shift) => `hsl(${Math.round((h * 60 + shift + 360) % 360)} ${Math.round(Math.max(s, 0.6) * 100)}% ${Math.round(Math.max(l, 0.64) * 100)}%)`;
    return [tone(0), tone(38), tone(-38)];
  }
  function vizPaints(ctx) {
    const key = vizAccent + document.documentElement.className;
    if (key === viz.key) return;
    viz.key = key;
    const mix = (color, strength) => `color-mix(in srgb, ${color} ${strength}%, transparent)`;
    const ramp = (color, strength) => {
      const g = ctx.createLinearGradient(0, 0, VIZ_W, 0);
      g.addColorStop(0, mix(color, 0)); g.addColorStop(0.14, mix(color, strength)); g.addColorStop(0.86, mix(color, strength)); g.addColorStop(1, mix(color, 0));
      return g;
    };
    const colors = vizColors(), [a, b, c] = colors;
    viz.fill = colors.map((col) => ramp(col, 46));
    viz.line = colors.map((col) => ramp(col, 96));
    viz.solid = colors.map((col) => mix(col, 92));
    // Spettro e linea: i tre colori in fila, il primo al centro, sfumati ai lati
    const across = (strength) => {
      const g = ctx.createLinearGradient(0, 0, VIZ_W, 0);
      g.addColorStop(0, mix(c, 0)); g.addColorStop(0.1, mix(c, strength * 0.8)); g.addColorStop(0.3, mix(b, strength)); g.addColorStop(0.5, mix(a, strength));
      g.addColorStop(0.7, mix(b, strength)); g.addColorStop(0.9, mix(c, strength * 0.8)); g.addColorStop(1, mix(c, 0));
      return g;
    };
    viz.across = across(92);
    // Aurora: luce piena sul nastro in basso di ogni velo, che sfuma salendo
    viz.veil = colors.map((col, s) => {
      const ribbon = VIZ_H * (0.8 - 0.07 * s), g = ctx.createLinearGradient(0, ribbon - VIZ_H * 0.75, 0, ribbon + 16);
      g.addColorStop(0, mix(col, 0)); g.addColorStop(0.55, mix(col, 16)); g.addColorStop(0.9, mix(col, 52)); g.addColorStop(1, mix(col, 70));
      return g;
    });
    // Punti di luce disegnati una volta sola e poi solo copiati: con il centro bianco (scintille) o morbidi (aloni)
    const sprite = (col, core) => {
      const s = document.createElement('canvas');
      s.width = s.height = 48;
      const g = s.getContext('2d'), r = g.createRadialGradient(24, 24, 0, 24, 24, 24);
      if (core) { r.addColorStop(0, 'rgba(255, 255, 255, 0.95)'); r.addColorStop(0.2, mix(col, 95)); r.addColorStop(0.5, mix(col, 32)); }
      else { r.addColorStop(0, mix(col, 70)); r.addColorStop(0.45, mix(col, 26)); }
      r.addColorStop(1, mix(col, 0));
      g.fillStyle = r;
      g.fillRect(0, 0, 48, 48);
      return s;
    };
    viz.sprites = colors.map((col) => sprite(col, true));
    viz.soft = colors.map((col) => sprite(col, false));
  }
  // Stato di ogni effetto, azzerato quando se ne sceglie un altro
  function vizReset(canvas) {
    viz.amp = [3, 3, 3];
    viz.aur = [0.06, 0.06, 0.06];
    viz.spec = new Float32Array(VIZ_BARS); viz.capY = new Float32Array(VIZ_BARS); viz.capV = new Float32Array(VIZ_BARS); viz.slowBar = new Float32Array(VIZ_BARS);
    viz.specPeak = 0.4; viz.sparks = []; viz.fw = []; viz.stars = null; viz.orbit = 0; viz.spawn = 0; viz.armed = true; viz.lineHist = null; viz.oscPeak = 0.2;
    if (canvas) canvas.getContext('2d').clearRect(0, 0, VIZ_W, VIZ_H);
  }
  function vizFrame(now) {
    viz.raf = 0;
    const mode = document.documentElement.dataset.viz;
    const canvas = VIZ_CANVAS.has(mode) ? document.querySelector('#beats-viz canvas') : null;
    const glow = mode === 'pulse' ? document.getElementById('beats-glow') : null;
    if (!fullOpen || quietOn || document.hidden || !(canvas || glow)) return;
    viz.raf = requestAnimationFrame(vizFrame);
    if (now - viz.last < VIZ_FRAME || performance.now() < flipUntil) return;
    const dt = Math.min(0.1, (now - viz.last) / 1000);
    viz.last = now;
    const playing = !!mk && mk.isPlaying;
    if (canvas && canvas !== viz.canvas) { // proporzioni vere della tela, perché cerchi e scintille restino tondi
      viz.ro = viz.ro || new ResizeObserver(([e]) => { const r = e.contentRect; if (r.width && r.height) viz.ar = (r.width * VIZ_H) / (r.height * VIZ_W); });
      if (viz.canvas) viz.ro.unobserve(viz.canvas);
      viz.canvas = canvas;
      viz.ro.observe(canvas);
    }
    if (mode !== viz.mode) { viz.mode = mode; vizReset(canvas); }
    vizListen(dt, playing, now, mode);
    vizShow(now);
    let moving;
    if (glow) moving = drawGlow(glow, dt, playing);
    else {
      const ctx = canvas.getContext('2d');
      vizPaints(ctx);
      ctx.clearRect(0, 0, VIZ_W, VIZ_H);
      ctx.globalCompositeOperation = 'lighter'; // dove si incrociano la luce si somma
      moving = VIZ_DRAW[mode](ctx, dt, playing);
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 1;
    }
    if (!moving) { cancelAnimationFrame(viz.raf); viz.raf = 0; }
  }
  // Onde: tre onde intrecciate come una treccia. L'ampiezza di ognuna segue i bassi, i medi o gli acuti del brano, corrono
  // al tempo del brano e a ogni colpo di batteria si gonfiano e si accendono. A musica ferma si distendono
  function drawWaves(ctx, dt, playing) {
    const energy = (viz.bands[0] + viz.bands[1] + viz.bands[2]) / 3, mid = VIZ_H * 0.6;
    viz.phase += dt * (playing ? (viz.period ? 0.5 * Math.PI / viz.period : 0.8 + 2.6 * energy) + 7 * viz.pulse : 0.3);
    let moving = playing;
    for (let s = 0; s < 3; s++) {
      const target = playing ? VIZ_H * (0.07 + 0.2 * viz.bands[s] + 0.12 * viz.pulse) : VIZ_H * 0.012;
      viz.amp[s] += (target - viz.amp[s]) * (1 - Math.exp(-dt / 0.05));
      if (Math.abs(target - viz.amp[s]) > 0.3) moving = true;
      // A 120 gradi l'una dall'altra restano una treccia: si incrociano sempre, senza mai sovrapporsi del tutto
      const amp = viz.amp[s], turns = (2.4 + s * 0.05) * 2 * Math.PI, shift = s * 2 * Math.PI / 3 + viz.phase + 0.4 * Math.sin(viz.phase * 0.13 + s * 2), thick = 3 + 13 * viz.bands[s] + 14 * viz.pulse;
      ctx.beginPath();
      for (let i = 0; i <= VIZ_POINTS; i++) {
        const u = i / VIZ_POINTS, x = u * VIZ_W, edge = Math.pow(Math.sin(Math.PI * u), 0.7), a = turns * u + shift;
        const y = mid + edge * amp * (Math.sin(a) + 0.2 * Math.sin(a * 2.3 - viz.phase));
        // Davanti è più spessa, dietro più sottile: è questo che fa vedere la treccia
        const w = edge * thick * (0.28 + 0.72 * (0.5 + 0.5 * Math.cos(a)));
        viz.up[i] = y - w; viz.down[i] = y + w;
        if (i) ctx.lineTo(x, viz.up[i]); else ctx.moveTo(x, viz.up[i]);
      }
      for (let i = VIZ_POINTS; i >= 0; i--) ctx.lineTo(i / VIZ_POINTS * VIZ_W, viz.down[i]);
      ctx.closePath();
      ctx.fillStyle = viz.fill[s];
      ctx.fill();
      ctx.beginPath();
      for (let i = 0; i <= VIZ_POINTS; i++) { const x = i / VIZ_POINTS * VIZ_W, y = (viz.up[i] + viz.down[i]) / 2; if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); }
      ctx.strokeStyle = viz.line[s];
      ctx.lineWidth = 2;
      ctx.stroke();
      if (viz.pulse > 0.12) { ctx.globalAlpha = 0.45 * viz.pulse; ctx.lineWidth = 6 + 8 * viz.pulse; ctx.stroke(); ctx.globalAlpha = 1; } // il colpo le accende
    }
    return moving;
  }
  // Livelli delle barre (spettro, raggi, matrice): metà dal volume della banda, metà da quanto si stacca dal suo solito,
  // così le barre saltano sui colpi invece di restare sempre alte; il cappello ricade piano
  function specLevels(dt, playing) {
    const n = VIZ_BARS, near = (tau) => 1 - Math.exp(-dt / tau), raw = viz.barsIn;
    let top = 0;
    for (let i = 0; i < n; i++) if (raw[i] > top) top = raw[i];
    viz.specPeak = Math.max(top, viz.specPeak + (0.3 - viz.specPeak) * near(6));
    let moving = playing;
    for (let i = 0; i < n; i++) {
      const v = raw[i];
      viz.slowBar[i] += (v - viz.slowBar[i]) * near(0.9);
      const stat = Math.min(1, v / Math.max(0.2, viz.specPeak)), jump = Math.max(0, Math.min(1, 0.45 + (v - viz.slowBar[i]) * 3.2));
      const level = playing ? Math.min(1, Math.pow(0.45 * stat + 0.55 * jump, 1.3) * (1 + 0.25 * viz.pulse)) : 0;
      viz.spec[i] += (level - viz.spec[i]) * near(level > viz.spec[i] ? 0.02 : 0.11);
      if (viz.spec[i] >= viz.capY[i]) { viz.capY[i] = viz.spec[i]; viz.capV[i] = 0; }
      else { viz.capV[i] += dt * 1.4; viz.capY[i] = Math.max(viz.spec[i], viz.capY[i] - viz.capV[i] * dt); }
      if (viz.capY[i] > 0.003) moving = true;
    }
    return moving;
  }
  // Spettro: barre a specchio, i bassi al centro e gli acuti verso i lati, con il cappello che ricade piano e un riflesso
  // più tenue sotto la linea; a ogni colpo si accendono. A musica ferma resta una fila di punti
  function drawSpectrum(ctx, dt, playing) {
    const moving = specLevels(dt, playing), n = VIZ_BARS, mid = VIZ_H * 0.7, up = VIZ_H * 0.58, down = VIZ_H * 0.18, cx = VIZ_W / 2;
    const slot = VIZ_W / 2 / (n + 1.5), w = slot * 0.58, r = Math.min(w / 2, 4);
    ctx.fillStyle = viz.across;
    ctx.beginPath();
    for (let i = 0; i < n; i++) {
      const h = 2 + viz.spec[i] * up, off = (i + 0.5) * slot + w / 2;
      ctx.roundRect(cx - off, mid - h, w, h, r);
      ctx.roundRect(cx + off - w, mid - h, w, h, r);
    }
    ctx.fill();
    if (viz.pulse > 0.12) { ctx.globalAlpha = 0.55 * viz.pulse; ctx.fill(); }
    ctx.globalAlpha = 0.28; // riflesso
    ctx.beginPath();
    for (let i = 0; i < n; i++) {
      const d = 1 + viz.spec[i] * down, off = (i + 0.5) * slot + w / 2;
      ctx.roundRect(cx - off, mid + 6, w, d, r);
      ctx.roundRect(cx + off - w, mid + 6, w, d, r);
    }
    ctx.fill();
    ctx.globalAlpha = 0.95; // cappelli
    ctx.beginPath();
    for (let i = 0; i < n; i++) {
      if (viz.capY[i] < 0.02) continue;
      const y = mid - 10 - viz.capY[i] * up, off = (i + 0.5) * slot + w / 2;
      ctx.roundRect(cx - off, y, w, 4, 2);
      ctx.roundRect(cx + off - w, y, w, 4, 2);
    }
    ctx.fill();
    return moving;
  }
  // Costellazione: punti di luce uniti da fili sottili quando sono vicini. Ognuno gira piano intorno al suo posto, più
  // largo e svelto quando il brano è pieno; a ogni colpo tutta la costellazione si allarga un poco dal centro e i fili si
  // accendono, poi torna subito com'era: respira con il brano senza mai disperdersi
  function drawConstellation(ctx, dt, playing) {
    const k = viz.ar, energy = (viz.bands[0] + viz.bands[1] + viz.bands[2]) / 3, cx = VIZ_W / 2, cy = VIZ_H * 0.55;
    if (!viz.stars) { // posti sparsi in modo uniforme: 16 colonne per 4 righe, ognuno spostato un po' a caso
      viz.stars = [];
      for (let i = 0; i < VIZ_STARS; i++) {
        const hx = VIZ_W * (0.03 + 0.94 * ((i % 16) + 0.15 + 0.7 * Math.random()) / 16);
        const hy = VIZ_H * (0.1 + 0.82 * (Math.floor(i / 16) + 0.15 + 0.7 * Math.random()) / 4);
        viz.stars.push({ hx, hy, x: hx, y: hy, c: i % 3, s: 2.2 + 2.6 * Math.random(), tw: Math.random() * 6.3 });
      }
    }
    const list = viz.stars, grow = 1 + 0.14 * viz.pulse;
    viz.orbit += ((playing ? 10 + 26 * energy : 0) - viz.orbit) * (1 - Math.exp(-dt / 0.4));
    for (const p of list) {
      p.tw += dt * (0.5 + 1.5 * energy);
      p.x = cx + (p.hx - cx) * grow + Math.cos(p.tw) * viz.orbit;
      p.y = cy + (p.hy - cy) * grow + Math.sin(p.tw * 1.3) * viz.orbit * 0.7 * k;
    }
    const moving = playing || viz.orbit > 0.2 || viz.pulse > 0.01;
    const n = list.length, D = 140, D2 = D * D, light = Math.min(1, 0.3 + 0.5 * energy + 0.7 * viz.pulse);
    ctx.strokeStyle = viz.across;
    ctx.lineWidth = 1.1 + 1.6 * viz.pulse;
    for (let b = 0; b < 3; b++) { // i fili più corti sono i più luminosi: tre gruppi, tre disegni
      ctx.beginPath();
      for (let i = 0; i < n; i++) {
        const a = list[i];
        for (let j = i + 1; j < n; j++) {
          const q = list[j], dx = a.x - q.x, dy = (a.y - q.y) / k, d2 = dx * dx + dy * dy;
          if (d2 >= D2) continue;
          const near = 1 - Math.sqrt(d2) / D;
          if ((near > 0.66 ? 2 : near > 0.33 ? 1 : 0) !== b) continue;
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(q.x, q.y);
        }
      }
      ctx.globalAlpha = light * (0.22 + 0.3 * b);
      ctx.stroke();
    }
    for (const p of list) { // le stelle, che sfumano ai lati come gli altri effetti
      const u = p.x / VIZ_W, edge = Math.max(0, Math.min(1, u / 0.08, (1 - u) / 0.08)), s = p.s * (1 + 0.6 * viz.bands[p.c] + 0.9 * viz.pulse);
      ctx.globalAlpha = edge * Math.min(1, 0.55 + 0.45 * viz.bands[p.c] + 0.3 * viz.pulse);
      ctx.drawImage(viz.sprites[p.c], p.x - s * 2, p.y - s * 2 * k, s * 4, s * 4 * k);
    }
    return moving;
  }
  // Matrice: un tabellone a luci. Ogni colonna è una banda di frequenze (a specchio dal centro) e si accende fino al suo
  // livello, con il punto più alto che resta un attimo; a ogni colpo tutto il tabellone brilla di più
  function drawMatrix(ctx, dt, playing) {
    const moving = specLevels(dt, playing), n = VIZ_BARS, rows = VIZ_ROWS, k = viz.ar, cx = VIZ_W / 2;
    const pitch = VIZ_W / 2 / (n + 1), dotW = pitch * 0.62, dotH = dotW * k, step = Math.min(VIZ_H * 0.9 / rows, dotH * 1.45), bottom = VIZ_H * 0.94;
    ctx.globalAlpha = 0.09; // le luci spente, tutte insieme
    ctx.fillStyle = viz.solid[1];
    ctx.beginPath();
    for (let i = 0; i < n; i++) {
      const off = (i + 0.5) * pitch;
      for (let r = 0; r < rows; r++) {
        const y = bottom - (r + 1) * step;
        ctx.rect(cx - off - dotW / 2, y, dotW, dotH);
        ctx.rect(cx + off - dotW / 2, y, dotW, dotH);
      }
    }
    ctx.fill();
    for (let g = 0; g < 3; g++) { // le accese, in tre fasce di colore dal basso
      const r1 = Math.floor(g * rows / 3), r2 = Math.floor((g + 1) * rows / 3);
      let any = false;
      ctx.beginPath();
      for (let i = 0; i < n; i++) {
        const lit = Math.min(r2, Math.round(viz.spec[i] * rows)), off = (i + 0.5) * pitch;
        for (let r = r1; r < lit; r++) {
          const y = bottom - (r + 1) * step;
          ctx.rect(cx - off - dotW / 2, y, dotW, dotH);
          ctx.rect(cx + off - dotW / 2, y, dotW, dotH);
          any = true;
        }
      }
      if (!any) continue;
      ctx.fillStyle = viz.solid[g];
      ctx.globalAlpha = 0.85;
      ctx.fill();
      if (viz.pulse > 0.12) { ctx.globalAlpha = 0.5 * viz.pulse; ctx.fill(); }
    }
    ctx.globalAlpha = 0.9; // il punto più alto di ogni colonna, con un alone
    for (let i = 0; i < n; i++) {
      const top = Math.round(viz.capY[i] * rows);
      if (top < 1) continue;
      const y = bottom - top * step + dotH / 2, off = (i + 0.5) * pitch, s = dotW * 0.9, img = viz.sprites[top > rows * 2 / 3 ? 2 : top > rows / 3 ? 1 : 0];
      ctx.drawImage(img, cx - off - s, y - s * k, 2 * s, 2 * s * k);
      ctx.drawImage(img, cx + off - s, y - s * k, 2 * s, 2 * s * k);
    }
    return moving;
  }
  // Scintille: luci che salgono dal basso, più fitte quando il brano è pieno, con una raffica a ogni colpo di batteria
  function drawSparks(ctx, dt, playing) {
    const list = viz.sparks, energy = (viz.bands[0] + viz.bands[1] + viz.bands[2]) / 3;
    if (playing) {
      viz.spawn += dt * (10 + 110 * energy);
      if (viz.pulse > 0.5 && viz.armed) { viz.armed = false; viz.spawn += 20 + 30 * viz.pulse; }
    }
    if (viz.pulse < 0.2) viz.armed = true;
    for (; viz.spawn >= 1; viz.spawn--) {
      if (list.length >= VIZ_SPARKS) continue;
      const c = Math.random() < 0.5 ? 0 : Math.random() < 0.6 ? 1 : 2;
      list.push({ x: VIZ_W * (0.05 + 0.9 * Math.random()), y: VIZ_H * (0.98 + 0.06 * Math.random()), vx: (Math.random() - 0.5) * 40,
        vy: -(40 + 120 * Math.random()) * (0.6 + 0.9 * energy + 1.2 * viz.pulse), life: 0, max: 1.4 + 2.2 * Math.random(), size: 4 + 8 * Math.random(), c, tw: Math.random() * 6.3 });
    }
    const k = viz.ar;
    for (let i = list.length - 1; i >= 0; i--) {
      const p = list[i];
      p.life += dt;
      if (p.life >= p.max || p.y < 0) { list[i] = list[list.length - 1]; list.pop(); continue; }
      p.x += (p.vx + 18 * Math.sin(p.tw + p.life * 2.4)) * dt;
      p.y += p.vy * dt;
      p.vy *= Math.exp(-dt * 0.4);
      const t = p.life / p.max, s = p.size * (1 + 0.5 * viz.bands[p.c] + 0.8 * viz.pulse) * (0.75 + 0.25 * Math.sin(p.tw * 3 + p.life * 10));
      ctx.globalAlpha = Math.max(0, Math.min(1, p.life * 6) * (1 - t) * Math.min(1, p.y / (VIZ_H * 0.3)));
      ctx.drawImage(viz.sprites[p.c], p.x - s, p.y - s * k, 2 * s, 2 * s * k);
    }
    return playing || list.length > 0;
  }
  // Fuochi: a ogni colpo forte esplode un fuoco d'artificio in un punto a caso, di uno dei tre colori; le scintille si
  // allargano, cadono piano e si spengono
  function drawFireworks(ctx, dt, playing) {
    const list = viz.fw, k = viz.ar;
    if (playing && viz.pulse > 0.55 && viz.armed) {
      viz.armed = false;
      const n = Math.round(50 + 40 * viz.pulse), x = VIZ_W * (0.12 + 0.76 * Math.random()), y = VIZ_H * (0.22 + 0.3 * Math.random());
      const c = Math.floor(Math.random() * 3), speed = 150 + 210 * viz.pulse;
      list.push({ x, y, vx: 0, vy: 0, life: 0, max: 0.3, c, s: 48, flash: true });
      for (let i = 0; i < n && list.length < 700; i++) {
        const ang = i / n * 2 * Math.PI + Math.random() * 0.25, v = speed * (0.55 + 0.45 * Math.random());
        list.push({ x, y, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v * k, life: 0, max: 0.9 + 0.8 * Math.random(), c, s: 4.5 + 4 * Math.random() });
      }
    }
    if (viz.pulse < 0.25) viz.armed = true;
    const drag = Math.exp(-dt * 1.7), fall = 150 * k * dt;
    for (let i = list.length - 1; i >= 0; i--) {
      const p = list[i];
      p.life += dt;
      if (p.life >= p.max) { list[i] = list[list.length - 1]; list.pop(); continue; }
      if (!p.flash) { p.vx *= drag; p.vy = p.vy * drag + fall; p.x += p.vx * dt; p.y += p.vy * dt; }
      const t = p.life / p.max, s = p.s * (p.flash ? 1 + t : 1 + 0.4 * viz.pulse), a = Math.max(0, p.flash ? 0.85 * (1 - t) : (1 - t) * (1 - t * 0.5));
      if (!p.flash) { // la scia: la stessa luce un po' indietro, più piccola e tenue
        const ts = s * 0.65, tx = p.x - p.vx * dt * 2.5, ty = p.y - p.vy * dt * 2.5;
        ctx.globalAlpha = a * 0.45;
        ctx.drawImage(viz.sprites[p.c], tx - ts, ty - ts * k, 2 * ts, 2 * ts * k);
      }
      ctx.globalAlpha = a;
      ctx.drawImage(p.flash ? viz.soft[p.c] : viz.sprites[p.c], p.x - s, p.y - s * k, 2 * s, 2 * s * k);
    }
    return playing || list.length > 0;
  }
  // Aurora: tre veli di luce appesi a un nastro ondulato, luminosi in basso e sfumati verso l'alto, con le strisce
  // verticali tipiche. Si alzano con bassi, medi e acuti e si accendono a ogni colpo
  function drawAurora(ctx, dt, playing) {
    const energy = (viz.bands[0] + viz.bands[1] + viz.bands[2]) / 3, P = VIZ_POINTS, up = viz.up, foot = viz.down;
    viz.phase += dt * (playing ? 0.25 + 1.0 * energy + 2.4 * viz.pulse : 0.1);
    ctx.lineCap = 'butt';
    let moving = playing;
    for (let s = 0; s < 3; s++) {
      const target = playing ? 0.22 + 0.5 * viz.bands[s] + 0.25 * viz.pulse : 0.05;
      viz.aur[s] += (target - viz.aur[s]) * (1 - Math.exp(-dt / 0.1));
      if (Math.abs(target - viz.aur[s]) > 0.003) moving = true;
      const h = VIZ_H * viz.aur[s], ph = viz.phase * (0.6 + 0.25 * s) + s * 2.3, ribbon = VIZ_H * (0.8 - 0.07 * s);
      const glow = 0.55 + 0.45 * Math.min(1, viz.bands[s] + viz.pulse);
      for (let i = 0; i <= P; i++) {
        const u = i / P, edge = Math.pow(Math.sin(Math.PI * u), 1.1);
        foot[i] = ribbon + 16 * Math.sin(u * 5 + ph) + 7 * Math.sin(u * 13 - ph * 1.4);
        up[i] = foot[i] - edge * h * (0.45 + 0.55 * Math.pow(0.5 + 0.5 * Math.sin(u * 3.4 + ph * 0.8), 1.5));
      }
      ctx.beginPath(); // il velo
      for (let i = 0; i <= P; i++) { const x = i / P * VIZ_W; if (i) ctx.lineTo(x, up[i]); else ctx.moveTo(x, up[i]); }
      for (let i = P; i >= 0; i--) ctx.lineTo(i / P * VIZ_W, foot[i]);
      ctx.closePath();
      ctx.fillStyle = viz.veil[s];
      ctx.globalAlpha = glow * 0.75;
      ctx.fill();
      ctx.beginPath(); // le strisce verticali, che scorrono piano
      for (let i = 1; i < P; i++) {
        const q = 0.5 + 0.5 * Math.sin(i * 2.1 + ph * 3 + s);
        if (q < 0.55) continue;
        const x = i / P * VIZ_W;
        ctx.moveTo(x, foot[i]);
        ctx.lineTo(x, foot[i] - (foot[i] - up[i]) * q);
      }
      ctx.strokeStyle = viz.veil[s];
      ctx.lineWidth = 3;
      ctx.globalAlpha = glow * 0.5;
      ctx.stroke();
      ctx.beginPath(); // il bordo basso, il più luminoso
      for (let i = 0; i <= P; i++) { const x = i / P * VIZ_W; if (i) ctx.lineTo(x, foot[i]); else ctx.moveTo(x, foot[i]); }
      ctx.strokeStyle = viz.line[s];
      ctx.lineWidth = 7;
      ctx.globalAlpha = glow * 0.25;
      ctx.stroke();
      ctx.lineWidth = 1.6;
      ctx.globalAlpha = glow * 0.85;
      ctx.stroke();
    }
    return moving;
  }
  // Linea: la forma vera del suono, come su un oscilloscopio, con la scia più tenue dei due momenti prima; a ogni colpo
  // si allarga e si accende
  function drawLine(ctx, dt, playing) {
    const n = VIZ_TRACE, src = viz.traceIn;
    if (!viz.lineHist) viz.lineHist = [new Float32Array(n), new Float32Array(n), new Float32Array(n)];
    const [cur, e1, e2] = viz.lineHist;
    e2.set(e1);
    e1.set(cur);
    let peak = 0;
    const follow = playing ? 0.65 : 1 - Math.exp(-dt / 0.1);
    for (let j = 0; j < n; j++) {
      cur[j] += ((playing ? src[j] : 0) - cur[j]) * follow;
      if (Math.abs(cur[j]) > peak) peak = Math.abs(cur[j]);
    }
    viz.oscPeak = Math.max(peak, viz.oscPeak + (0.12 - viz.oscPeak) * (1 - Math.exp(-dt / 4)));
    const gain = VIZ_H * 0.36 / Math.max(0.1, viz.oscPeak) * (1 + 0.5 * viz.pulse), mid = VIZ_H * 0.6;
    const trace = (arr) => {
      ctx.beginPath();
      for (let j = 0; j < n; j++) {
        const u = j / (n - 1), y = mid + arr[j] * gain * Math.pow(Math.sin(Math.PI * u), 0.8);
        if (j) ctx.lineTo(u * VIZ_W, y); else ctx.moveTo(0, y);
      }
    };
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.strokeStyle = viz.across;
    ctx.lineWidth = 2;
    trace(e2); ctx.globalAlpha = 0.16; ctx.stroke();
    trace(e1); ctx.globalAlpha = 0.3; ctx.stroke();
    trace(cur);
    ctx.globalAlpha = 0.22 + 0.25 * viz.pulse; ctx.lineWidth = 14 + 18 * viz.pulse; ctx.stroke(); // alone
    ctx.globalAlpha = 0.5; ctx.lineWidth = 5.5; ctx.stroke();
    ctx.globalAlpha = 1; ctx.lineWidth = 2.8; ctx.stroke();
    return playing || peak > 0.003;
  }
  // Bagliore: la luce dietro la copertina respira con i bassi e si accende a ogni colpo di batteria
  function drawGlow(glow, dt, playing) {
    const target = playing ? 0.25 + 0.75 * viz.bands[0] : 0;
    viz.glow += (target - viz.glow) * (1 - Math.exp(-dt / 0.06));
    glow.style.transform = `scale(${(0.9 + 0.2 * viz.glow + 0.22 * viz.pulse).toFixed(3)})`;
    glow.style.opacity = Math.min(0.95, 0.22 + 0.36 * viz.glow + 0.35 * viz.pulse).toFixed(3);
    viz.glowDriven = true;
    return playing || viz.glow > 0.005 || viz.pulse > 0.005;
  }
  function vizCheck() {
    const mode = document.documentElement.dataset.viz;
    if (mode !== 'pulse' && viz.glowDriven) { // la luce torna allo stile della pagina (Gengy la usa come sfondo)
      viz.glowDriven = false;
      const g = document.getElementById('beats-glow');
      if (g) { g.style.transform = ''; g.style.opacity = ''; }
    }
    const target = VIZ_CANVAS.has(mode) ? document.querySelector('#beats-viz canvas') : mode === 'pulse' ? document.getElementById('beats-glow') : null;
    const wanted = fullOpen && !quietOn && !document.hidden && !!target;
    if (wanted && !viz.raf) { viz.last = performance.now() - 16; viz.slot.count = 0; viz.raf = requestAnimationFrame(vizFrame); }
    // L'audio si aggancia la prima volta che un effetto serve davvero (riprova ogni tanto, se il contesto non era partito)
    if (wanted && mk && mk.isPlaying && !ap.analyser && performance.now() - viz.tried > 8000) {
      viz.tried = performance.now();
      const el = document.getElementById('apple-music-player');
      if (el) audioGraph(el).catch(() => {});
    }
  }
  // Se il contesto audio non era potuto partire, il primo clic o tasto nella pagina lo sblocca
  const vizUnlock = () => { if (!ap.analyser && fullOpen) { viz.tried = -1e9; vizCheck(); } };
  addEventListener('pointerdown', vizUnlock, true);
  addEventListener('keydown', vizUnlock, true);

  const wait = () => (window.MusicKit && MusicKit.getInstance ? hook() : setTimeout(wait, 400));
  wait();
})();
